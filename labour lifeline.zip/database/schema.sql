-- PostgreSQL Database Schema for Labour Platform
-- Enables UUID generation and postgis extension if available
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Users Table (Core identity for both Workers and Employers)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone_number VARCHAR(15) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE,
    password_hash VARCHAR(255),
    role VARCHAR(20) NOT NULL CHECK (role IN ('worker', 'employer', 'admin')),
    full_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Workers Table
CREATE TABLE workers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    age INT CHECK (age >= 18),
    gender VARCHAR(10) CHECK (gender IN ('male', 'female', 'other')),
    address TEXT,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    daily_wage_expectation NUMERIC(10, 2) NOT NULL,
    languages_known VARCHAR(255)[], -- e.g., ['English', 'Hindi', 'Tamil']
    experience_years INT DEFAULT 0,
    availability_status VARCHAR(20) DEFAULT 'available' CHECK (availability_status IN ('available', 'busy', 'offline')),
    verification_status VARCHAR(20) DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
    aadhaar_number VARCHAR(12) UNIQUE,
    trust_score NUMERIC(3, 2) DEFAULT 5.00 CHECK (trust_score >= 0.00 AND trust_score <= 5.00),
    completed_jobs_count INT DEFAULT 0,
    profile_photo_url VARCHAR(255)
);

-- 3. Employers Table
CREATE TABLE employers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    company_name VARCHAR(150),
    business_category VARCHAR(100),
    address TEXT,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    contact_email VARCHAR(255),
    verification_status VARCHAR(20) DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
    trust_score NUMERIC(3, 2) DEFAULT 5.00 CHECK (trust_score >= 0.00 AND trust_score <= 5.00)
);

-- 4. Skills Table
CREATE TABLE skills (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    category VARCHAR(50) DEFAULT 'unskilled' CHECK (category IN ('skilled', 'unskilled', 'semi-skilled'))
);

-- Join table: Worker Skills mapping
CREATE TABLE worker_skills (
    worker_id UUID REFERENCES workers(id) ON DELETE CASCADE,
    skill_id INT REFERENCES skills(id) ON DELETE CASCADE,
    PRIMARY KEY (worker_id, skill_id)
);

-- 5. Jobs Table
CREATE TABLE jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employer_id UUID REFERENCES employers(id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    job_type VARCHAR(20) NOT NULL CHECK (job_type IN ('full-time', 'part-time', 'daily-wage', 'contract', 'emergency')),
    salary_wage NUMERIC(10, 2) NOT NULL,
    workers_needed INT DEFAULT 1,
    workers_hired INT DEFAULT 0,
    timing_schedule VARCHAR(100),
    duration VARCHAR(50),
    food_accommodation_provided BOOLEAN DEFAULT FALSE,
    job_address TEXT NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    contact_phone VARCHAR(15) NOT NULL,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'filled', 'completed', 'cancelled')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Join table: Job Required Skills mapping
CREATE TABLE job_required_skills (
    job_id UUID REFERENCES jobs(id) ON DELETE CASCADE,
    skill_id INT REFERENCES skills(id) ON DELETE CASCADE,
    PRIMARY KEY (job_id, skill_id)
);

-- 6. Applications Table (Worker applying to jobs)
CREATE TABLE applications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID REFERENCES jobs(id) ON DELETE CASCADE,
    worker_id UUID REFERENCES workers(id) ON DELETE CASCADE,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'shortlisted', 'hired', 'rejected', 'completed')),
    applied_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(job_id, worker_id)
);

-- 7. Payments Table (Escrow or direct wage logs)
CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID REFERENCES jobs(id) ON DELETE SET NULL,
    employer_id UUID REFERENCES employers(id) ON DELETE SET NULL,
    worker_id UUID REFERENCES workers(id) ON DELETE SET NULL,
    amount NUMERIC(10, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'escrowed' CHECK (status IN ('escrowed', 'released', 'refunded', 'failed')),
    gateway VARCHAR(30) NOT NULL, -- 'razorpay', 'stripe', 'paytm', 'upi'
    transaction_id VARCHAR(100) UNIQUE,
    invoice_number VARCHAR(50) UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    released_at TIMESTAMP WITH TIME ZONE
);

-- 8. Reviews Table (Mutual ratings system)
CREATE TABLE reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID REFERENCES jobs(id) ON DELETE SET NULL,
    reviewer_id UUID REFERENCES users(id) ON DELETE SET NULL,
    reviewee_id UUID REFERENCES users(id) ON DELETE SET NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. Notifications Table
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'job_alert', 'payment', 'chat', 'system'
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 10. Training Courses Table
CREATE TABLE training_courses (
    id SERIAL PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50) REFERENCES skills(name) ON DELETE SET NULL,
    video_url VARCHAR(255),
    quiz_questions JSONB, -- JSON representation of tests/quizzes
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexing for geo queries and performance
CREATE INDEX idx_workers_location ON workers (latitude, longitude);
CREATE INDEX idx_jobs_location ON jobs (latitude, longitude);
CREATE INDEX idx_applications_job_worker ON applications (job_id, worker_id);
CREATE INDEX idx_notifications_user_read ON notifications (user_id, is_read);
