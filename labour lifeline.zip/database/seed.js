/**
 * Database Seeding Script
 * Populates PostgreSQL and MongoDB databases with high-quality mock data for testing.
 * Includes workers, employers, skills, job postings, payments, reviews, and chats.
 */

const { Client } = require('pg');
const mongoose = require('mongoose');
require('dotenv').config();

// PostgreSQL Configuration
const pgClient = new Client({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/labour_db'
});

// MongoDB Models
const { ChatModel, MessageModel, WorkerPortfolioModel } = require('./mongodb_schema');

const SKILLS_LIST = [
  { name: 'Electrician', category: 'skilled' },
  { name: 'Plumber', category: 'skilled' },
  { name: 'Carpenter', category: 'skilled' },
  { name: 'Driver', category: 'skilled' },
  { name: 'Welder', category: 'skilled' },
  { name: 'Construction Worker', category: 'unskilled' },
  { name: 'Painter', category: 'semi-skilled' },
  { name: 'Security Guard', category: 'semi-skilled' },
  { name: 'Delivery Worker', category: 'unskilled' },
  { name: 'Housekeeping Worker', category: 'unskilled' },
  { name: 'Farm Worker', category: 'unskilled' },
  { name: 'Data Entry Operator', category: 'semi-skilled' },
  { name: 'Mechanic', category: 'skilled' }
];

async function seedPostgreSQL() {
  console.log('Seeding PostgreSQL...');
  await pgClient.connect();

  // Clean tables
  await pgClient.query('TRUNCATE users, workers, employers, skills, worker_skills, jobs, job_required_skills, applications, payments, reviews, notifications, training_courses CASCADE');

  // Insert Skills
  console.log('Inserting skills...');
  const skillIds = {};
  for (const s of SKILLS_LIST) {
    const res = await pgClient.query(
      'INSERT INTO skills (name, category) VALUES ($1, $2) RETURNING id',
      [s.name, s.category]
    );
    skillIds[s.name] = res.rows[0].id;
  }

  // Insert Users
  console.log('Inserting users...');
  // Password is 'password123' bcrypt-hashed (simulated hash for simple seeding)
  const passwordHash = '$2b$10$wE1cE3R1Bv2rKxJvJb1SNeCpH.C7p.u3p9fJ4KxMh5L3SXeH1uK2C';

  // Workers
  const rWorker1 = await pgClient.query(
    "INSERT INTO users (phone_number, email, password_hash, role, full_name) VALUES ('+919876543210', 'ramesh@example.com', $1, 'worker', 'Ramesh Kumar') RETURNING id",
    [passwordHash]
  );
  const rWorker2 = await pgClient.query(
    "INSERT INTO users (phone_number, email, password_hash, role, full_name) VALUES ('+919876543211', 'suresh@example.com', $1, 'worker', 'Suresh Prasad') RETURNING id",
    [passwordHash]
  );
  const rWorker3 = await pgClient.query(
    "INSERT INTO users (phone_number, email, password_hash, role, full_name) VALUES ('+919876543212', 'anil@example.com', $1, 'worker', 'Anil Sharma') RETURNING id",
    [passwordHash]
  );

  // Employers
  const rEmployer1 = await pgClient.query(
    "INSERT INTO users (phone_number, email, password_hash, role, full_name) VALUES ('+919999888877', 'kamal.builders@example.com', $1, 'employer', 'Kamal Builders Ltd') RETURNING id",
    [passwordHash]
  );
  const rEmployer2 = await pgClient.query(
    "INSERT INTO users (phone_number, email, password_hash, role, full_name) VALUES ('+919999888876', 'homeowner@example.com', $1, 'employer', 'Rajesh Patel') RETURNING id",
    [passwordHash]
  );

  const workerIds = {
    ramesh: rWorker1.rows[0].id,
    suresh: rWorker2.rows[0].id,
    anil: rWorker3.rows[0].id
  };

  const employerIds = {
    kamal: rEmployer1.rows[0].id,
    rajesh: rEmployer2.rows[0].id
  };

  // Insert Workers Profiles
  console.log('Inserting worker profiles...');
  const w1 = await pgClient.query(
    "INSERT INTO workers (user_id, age, gender, address, latitude, longitude, daily_wage_expectation, languages_known, experience_years, availability_status, verification_status, aadhaar_number, trust_score, completed_jobs_count, profile_photo_url) VALUES ($1, 28, 'male', 'HSR Layout, Bangalore', 12.910263, 77.645022, 600.00, ARRAY['Hindi', 'English', 'Kannada'], 5, 'available', 'verified', '123456789012', 4.80, 15, 'https://images.unsplash.com/photo-1540569014015-19a7be504e3a?w=150') RETURNING id",
    [workerIds.ramesh]
  );
  const w2 = await pgClient.query(
    "INSERT INTO workers (user_id, age, gender, address, latitude, longitude, daily_wage_expectation, languages_known, experience_years, availability_status, verification_status, aadhaar_number, trust_score, completed_jobs_count, profile_photo_url) VALUES ($1, 35, 'male', 'Marathahalli, Bangalore', 12.9562, 77.7019, 500.00, ARRAY['Hindi', 'Bengali'], 8, 'available', 'verified', '234567890123', 4.50, 24, 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150') RETURNING id",
    [workerIds.suresh]
  );
  const w3 = await pgClient.query(
    "INSERT INTO workers (user_id, age, gender, address, latitude, longitude, daily_wage_expectation, languages_known, experience_years, availability_status, verification_status, aadhaar_number, trust_score, completed_jobs_count, profile_photo_url) VALUES ($1, 24, 'male', 'Indiranagar, Bangalore', 12.971891, 77.641151, 800.00, ARRAY['Hindi', 'English', 'Telugu'], 3, 'available', 'pending', '345678901234', 4.90, 8, 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150') RETURNING id",
    [workerIds.anil]
  );

  const dbWorkerIds = {
    ramesh: w1.rows[0].id,
    suresh: w2.rows[0].id,
    anil: w3.rows[0].id
  };

  // Map Worker Skills
  await pgClient.query("INSERT INTO worker_skills (worker_id, skill_id) VALUES ($1, $2)", [dbWorkerIds.ramesh, skillIds['Electrician']]);
  await pgClient.query("INSERT INTO worker_skills (worker_id, skill_id) VALUES ($1, $2)", [dbWorkerIds.ramesh, skillIds['Mechanic']]);
  await pgClient.query("INSERT INTO worker_skills (worker_id, skill_id) VALUES ($1, $2)", [dbWorkerIds.suresh, skillIds['Painter']]);
  await pgClient.query("INSERT INTO worker_skills (worker_id, skill_id) VALUES ($1, $2)", [dbWorkerIds.suresh, skillIds['Construction Worker']]);
  await pgClient.query("INSERT INTO worker_skills (worker_id, skill_id) VALUES ($1, $2)", [dbWorkerIds.anil, skillIds['Carpenter']]);

  // Insert Employers Profiles
  console.log('Inserting employer profiles...');
  const emp1 = await pgClient.query(
    "INSERT INTO employers (user_id, company_name, business_category, address, latitude, longitude, contact_email, verification_status, trust_score) VALUES ($1, 'Kamal Builders Ltd', 'Construction', 'Whitefield, Bangalore', 12.9698, 77.7499, 'info@kamalbuilders.com', 'verified', 4.90) RETURNING id",
    [employerIds.kamal]
  );
  const emp2 = await pgClient.query(
    "INSERT INTO employers (user_id, company_name, business_category, address, latitude, longitude, contact_email, verification_status, trust_score) VALUES ($1, 'Patel Residences', 'Residential', 'Koramangala, Bangalore', 12.9352, 77.6244, 'rajesh.patel@example.com', 'verified', 4.70) RETURNING id",
    [employerIds.rajesh]
  );

  const dbEmployerIds = {
    kamal: emp1.rows[0].id,
    rajesh: emp2.rows[0].id
  };

  // Insert Jobs
  console.log('Inserting jobs...');
  const j1 = await pgClient.query(
    `INSERT INTO jobs (employer_id, title, description, job_type, salary_wage, workers_needed, workers_hired, timing_schedule, duration, food_accommodation_provided, job_address, latitude, longitude, contact_phone, status) 
     VALUES ($1, 'Urgent Electrician for Substation', 'Need a skilled electrician to install power lines and connect meters in new building complex.', 'emergency', 750.00, 2, 0, '9 AM - 6 PM', '3 Days', TRUE, 'Whitefield, Bangalore', 12.9698, 77.7499, '+919999888877', 'active') RETURNING id`,
    [dbEmployerIds.kamal]
  );
  const j2 = await pgClient.query(
    `INSERT INTO jobs (employer_id, title, description, job_type, salary_wage, workers_needed, workers_hired, timing_schedule, duration, food_accommodation_provided, job_address, latitude, longitude, contact_phone, status) 
     VALUES ($1, 'House Painting Project', 'Required experienced painters to paint a 3 BHK villa in Koramangala. Paint material will be provided.', 'contract', 550.00, 3, 0, '10 AM - 5 PM', '5 Days', FALSE, 'Koramangala, Bangalore', 12.9352, 77.6244, '+919999888876', 'active') RETURNING id`,
    [dbEmployerIds.rajesh]
  );

  const dbJobIds = {
    substation: j1.rows[0].id,
    painting: j2.rows[0].id
  };

  // Map Job Skills
  await pgClient.query("INSERT INTO job_required_skills (job_id, skill_id) VALUES ($1, $2)", [dbJobIds.substation, skillIds['Electrician']]);
  await pgClient.query("INSERT INTO job_required_skills (job_id, skill_id) VALUES ($1, $2)", [dbJobIds.painting, skillIds['Painter']]);

  // Insert Training Courses
  console.log('Inserting training courses...');
  const quizObj = JSON.stringify([
    { question: 'What does a wire with green insulation represent?', options: ['Phase/Live', 'Neutral', 'Ground/Earth'], answer: 'Ground/Earth' },
    { question: 'Which instrument is used to check voltage?', options: ['Ammeter', 'Multimeter', 'Odometer'], answer: 'Multimeter' }
  ]);
  await pgClient.query(
    "INSERT INTO training_courses (title, description, category, video_url, quiz_questions) VALUES ('Basic Electrical Safety', 'Learn how to handle high voltage wires, utilize grounding methods, and test circuits safely.', 'Electrician', 'https://www.youtube.com/embed/dQw4w9WgXcQ', $1)",
    [quizObj]
  );

  console.log('PostgreSQL Seeding Completed Successfully.');
  await pgClient.end();

  return { workerIds, dbWorkerIds, employerIds, dbEmployerIds, dbJobIds };
}

async function seedMongoDB(ids) {
  console.log('Seeding MongoDB...');
  const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/labour_db';
  await mongoose.connect(mongoUri);

  // Clear MongoDB
  await ChatModel.deleteMany({});
  await MessageModel.deleteMany({});
  await WorkerPortfolioModel.deleteMany({});

  // 1. Create Worker Portfolios
  console.log('Creating worker portfolios...');
  await WorkerPortfolioModel.create([
    {
      workerId: ids.dbWorkerIds.ramesh,
      bio: 'Expert electrician with 5 years experience in domestic and industrial wiring. Certified by National Skill Development Corp (NSDC).',
      previousWorkPhotos: [
        { url: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400', description: 'Rewired an industrial control panel' },
        { url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=400', description: 'Installed smart home panels' }
      ],
      certificates: [
        { title: 'Certified Electrician Grade-I', issuer: 'National Skill Development Corp', url: 'https://sample-certificates.com/elect-ramesh.pdf', verified: true }
      ],
      voiceIntroUrl: 'https://sample-audio.com/ramesh-intro.mp3'
    },
    {
      workerId: ids.dbWorkerIds.suresh,
      bio: 'Experienced painter specializing in commercial painting, exterior texture painting, and wood polishing. Hard worker.',
      previousWorkPhotos: [
        { url: 'https://images.unsplash.com/photo-1562259949-e8e7689d7828?w=400', description: 'Wall texture painting project' }
      ],
      certificates: [],
      voiceIntroUrl: ''
    }
  ]);

  // 2. Create Chat Room
  console.log('Creating chat room and messages...');
  const chat = await ChatModel.create({
    jobId: ids.dbJobIds.substation,
    employerId: ids.employerIds.kamal,
    workerId: ids.workerIds.ramesh,
    lastMessage: {
      text: 'I can start tomorrow morning at 9 AM.',
      senderId: ids.workerIds.ramesh,
      timestamp: new Date()
    }
  });

  // 3. Create Messages
  await MessageModel.create([
    {
      chatId: chat._id,
      senderId: ids.employerIds.kamal,
      messageType: 'text',
      content: { text: 'Hello Ramesh, are you available for the substation electrical wiring project?' },
      translations: {
        en: 'Hello Ramesh, are you available for the substation electrical wiring project?',
        hi: 'नमस्ते रमेश, क्या आप सबस्टेशन विद्युत तारों की परियोजना के लिए उपलब्ध हैं?',
        kn: 'ಹಲೋ ರಮೇಶ್, ನೀವು ಸಬ್‌ಸ್ಟೇಷನ್ ವಿದ್ಯುತ್ ವೈರಿಂಗ್ ಯೋಜನೆಗೆ ಲಭ್ಯವಿದ್ದೀರಾ?'
      }
    },
    {
      chatId: chat._id,
      senderId: ids.workerIds.ramesh,
      messageType: 'text',
      content: { text: 'Yes, sir. I have worked on similar sub-stations before.' },
      translations: {
        en: 'Yes, sir. I have worked on similar sub-stations before.',
        hi: 'हाँ, सर। मैंने पहले भी इस तरह के सब-स्टेशनों पर काम किया है।',
        kn: 'ಹೌದು, ಸರ್. ನಾನು ಈ ಹಿಂದೆ ಇದೇ ರೀತಿಯ ಸಬ್‌ಸ್ಟೇಷನ್‌ಗಳಲ್ಲಿ ಕೆಲಸ ಮಾಡಿದ್ದೇನೆ.'
      }
    },
    {
      chatId: chat._id,
      senderId: ids.employerIds.kamal,
      messageType: 'text',
      content: { text: 'Great, the daily wage is 750 INR. Will you be able to start tomorrow?' },
      translations: {
        en: 'Great, the daily wage is 750 INR. Will you be able to start tomorrow?',
        hi: 'बहुत बढ़िया, दैनिक वेतन 750 रुपये है। क्या आप कल से शुरू कर पाएंगे?',
        kn: 'ಉತ್ತಮ, ದಿನದ ಕೂಲಿ 750 ರೂ. ನಾಳೆಯಿಂದ ಕೆಲಸ ಪ್ರಾರಂಭಿಸಲು ಸಾಧ್ಯವೇ?'
      }
    },
    {
      chatId: chat._id,
      senderId: ids.workerIds.ramesh,
      messageType: 'text',
      content: { text: 'I can start tomorrow morning at 9 AM.' },
      translations: {
        en: 'I can start tomorrow morning at 9 AM.',
        hi: 'मैं कल सुबह 9 बजे काम शुरू कर सकता हूँ।',
        kn: 'ನಾನು ನಾಳೆ ಬೆಳಗ್ಗೆ 9 ಗಂಟೆಗೆ ಪ್ರಾರಂಭಿಸಬಹುದು.'
      }
    }
  ]);

  console.log('MongoDB Seeding Completed Successfully.');
  await mongoose.disconnect();
}

async function run() {
  try {
    const ids = await seedPostgreSQL();
    await seedMongoDB(ids);
    console.log('Database Seeding Finished Successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding databases:', error);
    process.exit(1);
  }
}

// Check if run directly
if (require.main === module) {
  run();
}
