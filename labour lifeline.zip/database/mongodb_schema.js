// MongoDB Schema Definition for Chats, Messages, and Worker Portfolios
// This file acts as documentation and Mongoose modeling guide for MongoDB.

const mongoose = require('mongoose');
const { Schema } = mongoose;

/**
 * 1. Chats (Rooms) Collection
 * Identifies a chat conversation between an Employer and a Worker.
 */
const ChatSchema = new Schema({
  jobId: { type: String, required: true }, // References PostgreSQL Job UUID
  employerId: { type: String, required: true }, // References PostgreSQL Employer UUID
  workerId: { type: String, required: true }, // References PostgreSQL Worker UUID
  lastMessage: {
    text: String,
    senderId: String,
    timestamp: { type: Date, default: Date.now }
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

// Indexing for quick retrieval of user chats
ChatSchema.index({ employerId: 1, workerId: 1 });
ChatSchema.index({ workerId: 1 });

/**
 * 2. Messages Collection
 * Stores individual messages inside a Chat Room.
 * Supports text, voice notes, attachments, and dynamic translation caching.
 */
const MessageSchema = new Schema({
  chatId: { type: Schema.Types.ObjectId, ref: 'Chat', required: true },
  senderId: { type: String, required: true }, // UUID of the user sending the message
  messageType: { 
    type: String, 
    enum: ['text', 'voice', 'image', 'file'], 
    default: 'text' 
  },
  content: {
    text: { type: String }, // Primary text message
    mediaUrl: { type: String }, // URL for voice note (.mp3/.wav), image or file
    duration: { type: Number } // Audio duration in seconds (if voice message)
  },
  translations: {
    // Dynamic translations cache
    en: String, // English
    hi: String, // Hindi
    kn: String, // Kannada
    ta: String, // Tamil
    te: String, // Telugu
    bn: String, // Bengali
    mr: String, // Marathi
    ur: String  // Urdu
  },
  isRead: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
}, { timestamps: true });

MessageSchema.index({ chatId: 1, createdAt: 1 });

/**
 * 3. Worker Portfolios Collection
 * Stores unstructured media and profile information that doesn't fit standard SQL.
 */
const WorkerPortfolioSchema = new Schema({
  workerId: { type: String, required: true, unique: true }, // PostgreSQL Worker UUID
  bio: { type: String },
  previousWorkPhotos: [{
    url: { type: String, required: true },
    description: { type: String },
    uploadedAt: { type: Date, default: Date.now }
  }],
  certificates: [{
    title: { type: String, required: true },
    issuer: { type: String },
    url: { type: String, required: true },
    issuedAt: { type: Date },
    verified: { type: Boolean, default: false }
  }],
  voiceIntroUrl: { type: String }, // Audio clip of worker describing their skills
  offlineCache: {
    savedJobs: [{ type: String }], // PostgreSQL Job UUIDs saved offline
    lastSyncedAt: { type: Date, default: Date.now }
  }
}, { timestamps: true });

WorkerPortfolioSchema.index({ workerId: 1 });

module.exports = {
  ChatModel: mongoose.model('Chat', ChatSchema),
  MessageModel: mongoose.model('Message', MessageSchema),
  WorkerPortfolioModel: mongoose.model('WorkerPortfolio', WorkerPortfolioSchema)
};
