import math
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

app = FastAPI(
    title="Labour Platform AI/ML Engine",
    description="Microservice for worker job matching, fraud detection, voice processing, and portfolio builds.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Helper function: Haversine distance in KM
def calculate_haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    # Radius of the Earth in km
    R = 6371.0
    
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    
    a = (math.sin(dlat / 2) ** 2 + 
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * 
         math.sin(dlon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    return R * c

# -----------------
# 1. Matchmaking Engine
# -----------------

class WorkerProfile(BaseModel):
    skills: List[str]
    wage: float
    experience: int
    lat: float
    lng: float

class JobItem(BaseModel):
    id: str
    title: str
    description: str
    skills: List[str]
    wage: float
    lat: float
    lng: float

class MatchRequest(BaseModel):
    worker: WorkerProfile
    jobs: List[JobItem]

@app.post("/match", response_model=Dict[str, Any])
def match_jobs(payload: MatchRequest):
    worker = payload.worker
    jobs = payload.jobs
    
    if not jobs:
        return {"matches": []}
        
    results = []
    
    # Extract worker skills as text string for vectorizer
    worker_skills_str = " ".join(worker.skills)
    
    for job in jobs:
        # A. Skill matching using TF-IDF and Cosine Similarity
        job_skills_str = " ".join(job.skills)
        
        # Add title and description to vocabulary for richer semantic context
        corpus = [worker_skills_str, f"{job_skills_str} {job.title} {job.description}"]
        
        try:
            vectorizer = TfidfVectorizer().fit_transform(corpus)
            vectors = vectorizer.toarray()
            skill_score = float(cosine_similarity([vectors[0]], [vectors[1]])[0][0])
        except Exception:
            # Fallback if vocabulary parsing fails (e.g. empty skills strings)
            intersection = set(worker.skills).intersection(set(job.skills))
            union = set(worker.skills).union(set(job.skills))
            skill_score = len(intersection) / len(union) if union else 0.0
            
        # B. Distance calculation and scoring (1.0 close -> 0.0 far, max 30km bounds)
        distance = calculate_haversine(worker.lat, worker.lng, job.lat, job.lng)
        distance_score = max(0.0, 1.0 - (distance / 30.0)) # 30km is upper bound
        
        # C. Wage expectations score
        # If job pays equal or more than expected, score is 1.0. Otherwise, apply an exponential penalty
        if job.wage >= worker.wage:
            wage_score = 1.0
        else:
            wage_score = float(math.exp((job.wage - worker.wage) / worker.wage))
            
        # D. Weighted aggregation of features
        # 45% skills match + 35% distance + 20% wage satisfaction
        final_score = (0.45 * skill_score) + (0.35 * distance_score) + (0.20 * wage_score)
        
        # Experience boost (adds up to 0.05 bonus for high experience years)
        experience_bonus = min(0.05, worker.experience * 0.005)
        final_score = min(1.0, final_score + experience_bonus)
        
        results.append({
            "job_id": job.id,
            "score": round(final_score, 4),
            "distance_km": round(distance, 2),
            "skill_match_pct": round(skill_score * 100, 1),
            "wage_match_pct": round(wage_score * 100, 1)
        })
        
    # Sort matches by highest final score
    results.sort(key=lambda x: x["score"], reverse=True)
    
    return {"matches": results}

# -----------------
# 2. Fraud & Spam Detection
# -----------------

class FraudCheckRequest(BaseModel):
    reviewer_id: str
    reviewee_id: str
    rating: int
    comment: str
    recent_reviews_count_1h: int
    duplicated_reviews_count: int

@app.post("/fraud-check", response_model=Dict[str, Any])
def detect_fraud(payload: FraudCheckRequest):
    risk_score = 0.0
    reasons = []
    
    # Scenario A: Rating is low but duplicate text is used, or rating is highly suspicious
    if payload.duplicated_reviews_count > 2:
        risk_score += 0.40
        reasons.append("Identical review text submitted multiple times.")
        
    # Scenario B: High speed rating spam
    if payload.recent_reviews_count_1h > 5:
        risk_score += 0.35
        reasons.append("Abnormally high volume of ratings from this user in a short timeframe.")
        
    # Scenario C: Suspicious keyword matching in comment (e.g. promotional, fake payment claims)
    spam_words = ["free money", "hack", "pay me outside", "scam", "cheat", "double income"]
    comment_lower = payload.comment.lower()
    spam_count = sum(1 for word in spam_words if word in comment_lower)
    if spam_count > 0:
        risk_score += 0.20
        reasons.append("Comment contains suspicious keywords indicating potential scam or promo.")
        
    risk_level = "low"
    if risk_score >= 0.60:
        risk_level = "high"
    elif risk_score >= 0.30:
        risk_level = "medium"
        
    return {
        "risk_score": round(min(1.0, risk_score), 2),
        "risk_level": risk_level,
        "flagged": risk_level == "high",
        "reasons": reasons
    }

# -----------------
# 3. Voice Command NLP Parser
# -----------------

class VoiceCommandRequest(BaseModel):
    transcript: str

@app.post("/voice-command", response_model=Dict[str, Any])
def parse_voice_command(payload: VoiceCommandRequest):
    text = payload.transcript.lower()
    
    # Mappings for skills detection
    skills_map = {
        "electrician": ["electrician", "bijli", "wiring", "light", "board", "fan"],
        "painter": ["painter", "paint", "putty", "rang", "color", "brush"],
        "plumber": ["plumber", "pipe", "tap", "leak", "flush", "nal"],
        "carpenter": ["carpenter", "wood", "furniture", "door", "table", "chair"],
        "driver": ["driver", "car", "gaadi", "truck", "cab"],
        "security": ["guard", "security", "chowkidar", "gatekeeper"]
    }
    
    detected_skill = "Unspecified"
    for skill, keywords in skills_map.items():
        if any(kw in text for kw in keywords):
            detected_skill = skill
            break
            
    # Locate indicators
    location = "Nearby"
    if "near me" in text or "paas" in text:
        location = "Current Location"
    elif "bangalore" in text or "bengaluru" in text:
        location = "Bangalore"
    elif "koramangala" in text:
        location = "Koramangala"
    elif "whitefield" in text:
        location = "Whitefield"
        
    action = "job_search"
    if "hire" in text or "dhoondna" in text or "chahiye" in text:
        if "worker" in text or "labour" in text:
            action = "hire_worker"
            
    return {
        "action": action,
        "intent_confidence": 0.95 if detected_skill != "Unspecified" else 0.50,
        "entities": {
            "skill": detected_skill,
            "location": location
        },
        "query_tokens": text.split()
    }

# -----------------
# 4. AI Portfolio / Resume Builder
# -----------------

class ResumeBuilderRequest(BaseModel):
    name: str
    experience_years: int
    skills: List[str]
    languages: List[str]
    location: str

@app.post("/resume-builder", response_model=Dict[str, Any])
def build_resume(payload: ResumeBuilderRequest):
    skills_str = ", ".join(payload.skills)
    languages_str = ", ".join(payload.languages)
    
    # Generates a professional description structured for worker profiles
    bio = (
        f"Hi, I am {payload.name}. I am a professional who specializes in {skills_str}. "
        f"I have over {payload.experience_years} years of practical experience working in {payload.location} "
        f"and adjacent areas. I speak {languages_str} fluently. I take pride in providing quality work, "
        f"maintaining job safety standards, and keeping project schedules. Let's work together!"
    )
    
    return {
        "generated_bio": bio,
        "skills_highlighted": payload.skills,
        "profile_strength_score": min(100, 40 + (payload.experience_years * 5) + (len(payload.skills) * 10))
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
