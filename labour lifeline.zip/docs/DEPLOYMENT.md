# Deployment Guide: AI-Powered Labour Hiring Platform

This guide outlines deployment procedures for Docker, AWS ECS/EKS, and Google Cloud Kubernetes (GKE).

---

## 1. Local Quickstart (Docker Compose)
To launch the entire platform cluster locally in development mode:

1. **Install Prerequisites**: Install Docker Desktop and Git.
2. **Launch Containers**: Run the following command in the root folder containing `docker-compose.yml`:
   ```bash
   docker-compose up --build
   ```
3. **Verify running containers**:
   - Web App Portal: `http://localhost:3000`
   - Express Backend: `http://localhost:5000`
   - AI/ML Microservice: `http://localhost:8000`
   - Postgres Database: `localhost:5432`
   - MongoDB: `localhost:27017`

---

## 2. Cloud Production Deployment (AWS ECS + Fargate)

A scalable deployment strategy is using **AWS Elastic Container Service (ECS)** with serverless **AWS Fargate** nodes.

### Step 2.1: Setup DB Instances
1. **Relational Database**: Launch an **Amazon RDS PostgreSQL** multi-AZ cluster. Record the host endpoint.
2. **Unstructured Database**: Spin up an **Amazon DocumentDB** (MongoDB compatible cluster).
3. **Caching**: Setup an **Amazon ElastiCache for Redis** instance.

### Step 2.2: Build and Push Docker Images to AWS ECR
Create AWS Elastic Container Registries (ECR) for the three app components:
```bash
# Login to AWS ECR
aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin <aws_account_id>.dkr.ecr.ap-south-1.amazonaws.com

# Build and Push Backend
docker build -t labour-backend -f docker/Dockerfile.backend ./backend
docker tag labour-backend:latest <aws_account_id>.dkr.ecr.ap-south-1.amazonaws.com/labour-backend:latest
docker push <aws_account_id>.dkr.ecr.ap-south-1.amazonaws.com/labour-backend:latest

# Build and Push AI Engine
docker build -t labour-ai -f docker/Dockerfile.ai ./ai-engine
docker tag labour-ai:latest <aws_account_id>.dkr.ecr.ap-south-1.amazonaws.com/labour-ai:latest
docker push <aws_account_id>.dkr.ecr.ap-south-1.amazonaws.com/labour-ai:latest

# Build and Push Next.js Web
docker build -t labour-frontend -f docker/Dockerfile.frontend ./frontend
docker tag labour-frontend:latest <aws_account_id>.dkr.ecr.ap-south-1.amazonaws.com/labour-frontend:latest
docker push <aws_account_id>.dkr.ecr.ap-south-1.amazonaws.com/labour-frontend:latest
```

### Step 2.3: Configure ECS Task Definitions
1. Define a task family with **Fargate** launch compatibility.
2. Specify environment keys:
   - `DATABASE_URL` (AWS RDS Postgres string)
   - `MONGODB_URI` (AWS DocumentDB link)
   - `REDIS_URL` (AWS ElastiCache cluster connection)
   - `AI_ENGINE_URL` (Internal ECS service mesh locator)
   - `JWT_SECRET` (A strong cryptographic secret key)
3. Attach an **Application Load Balancer (ALB)** to route port `80/443` to the web container (`3000`), proxy `/api` calls to the backend container (`5000`), and configure SSL certificates using AWS Certificate Manager.

---

## 3. Kubernetes Deployment (EKS / GKE)

For high scalability and auto-recovery, deploy the platform using **Kubernetes**.

Apply the configurations in order:

### 3.1 Environment Secrets & ConfigMap (`k8s/config.yaml`)
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: labour-app-config
data:
  AI_ENGINE_URL: "http://ai-engine-service:8000"
---
apiVersion: v1
kind: Secret
metadata:
  name: labour-app-secrets
type: Opaque
data:
  DATABASE_URL: <base64_encoded_connection_string>
  MONGODB_URI: <base64_encoded_mongodb_uri>
  REDIS_URL: <base64_encoded_redis_url>
  JWT_SECRET: <base64_encoded_jwt_secret>
```

### 3.2 Backend Service Deployment (`k8s/backend-deploy.yaml`)
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: labour-backend-deployment
spec:
  replicas: 3
  selector:
    matchLabels:
      app: labour-backend
  template:
    metadata:
      labels:
        app: labour-backend
    spec:
      containers:
      - name: backend
        image: <aws_account_id>.dkr.ecr.ap-south-1.amazonaws.com/labour-backend:latest
        ports:
        - containerPort: 5000
        envFrom:
        - secretRef:
            name: labour-app-secrets
        - configMapRef:
            name: labour-app-config
---
apiVersion: v1
kind: Service
metadata:
  name: labour-backend-service
spec:
  selector:
    app: labour-backend
  ports:
    - protocol: TCP
      port: 5000
      targetPort: 5000
```

### 3.3 Apply and Scale
```bash
kubectl apply -f k8s/config.yaml
kubectl apply -f k8s/backend-deploy.yaml

# Enable HPA (Horizontal Pod Autoscaler) based on 70% CPU usage
kubectl autoscale deployment labour-backend-deployment --cpu-percent=70 --min=3 --max=10
```
