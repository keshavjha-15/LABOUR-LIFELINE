'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export interface User {
  id: string;
  role: 'worker' | 'employer' | 'admin';
  fullName: string;
  phoneNumber: string;
  email?: string;
  token?: string;
}

interface AuthContextProps {
  user: User | null;
  loading: boolean;
  login: (phoneOrEmail: string, role?: 'worker' | 'employer') => Promise<void>;
  register: (fullName: string, phone: string, role: 'worker' | 'employer', extra?: any) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextProps>({
  user: null,
  loading: true,
  login: async () => {},
  register: async () => {},
  logout: () => {},
  isAuthenticated: false
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('app_user');
    if (stored) {
      try {
        setUser(JSON.parse(stored));
      } catch (e) {
        localStorage.removeItem('app_user');
      }
    }
    setLoading(false);
  }, []);

  // Mock Authentication Login (Fallback enabled)
  const login = async (phoneOrEmail: string, role: 'worker' | 'employer' = 'worker') => {
    setLoading(true);
    try {
      // Direct mock details simulation to guarantee immediate UI interaction
      const mockUser: User = {
        id: role === 'worker' ? 'worker-uuid-ramesh-123' : 'employer-uuid-kamal-456',
        role,
        fullName: role === 'worker' ? 'Ramesh Kumar' : 'Kamal Builders Ltd',
        phoneNumber: phoneOrEmail.includes('+91') ? phoneOrEmail : '+919876543210',
        email: phoneOrEmail.includes('@') ? phoneOrEmail : `${role}@example.com`,
        token: 'mock_jwt_token_antigravity'
      };

      setUser(mockUser);
      localStorage.setItem('app_user', JSON.stringify(mockUser));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const register = async (fullName: string, phone: string, role: 'worker' | 'employer', extra?: any) => {
    setLoading(true);
    try {
      const mockUser: User = {
        id: `user-uuid-${Math.random().toString(36).substr(2, 9)}`,
        role,
        fullName,
        phoneNumber: phone,
        email: `${fullName.toLowerCase().replace(/\s+/g, '')}@example.com`,
        token: 'mock_jwt_token_antigravity'
      };

      setUser(mockUser);
      localStorage.setItem('app_user', JSON.stringify(mockUser));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('app_user');
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
