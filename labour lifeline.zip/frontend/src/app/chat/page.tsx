'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import { useRouter } from 'next/navigation';
import { 
  Send, Mic, Image, ArrowLeft, Languages, Volume2, 
  Paperclip, Sparkles, Check, CheckCheck, User 
} from 'lucide-react';

interface Message {
  id: string;
  senderId: string;
  messageType: 'text' | 'voice' | 'image';
  content: {
    text?: string;
    mediaUrl?: string;
  };
  translations?: Record<string, string>;
  createdAt: string;
}

interface ChatRoom {
  id: string;
  jobTitle: string;
  employerName: string;
  workerName: string;
  lastMessageText: string;
}

export default function ChatPage() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const router = useRouter();

  const [rooms, setRooms] = useState<ChatRoom[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [translationLang, setTranslationLang] = useState<string>('none');
  const [isRecording, setIsRecording] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // MOCK CHAT DATA
  const mockRooms: ChatRoom[] = [
    { id: 'room-1', jobTitle: 'Urgent Substation Electrician', employerName: 'Kamal Builders Ltd', workerName: 'Ramesh Kumar', lastMessageText: 'I can start tomorrow morning at 9 AM.' }
  ];

  const mockMessages: Message[] = [
    {
      id: 'msg-1',
      senderId: 'employer-uuid-kamal-456', // Employer
      messageType: 'text',
      content: { text: 'Hello Ramesh, are you available for the substation electrical wiring project?' },
      translations: {
        en: 'Hello Ramesh, are you available for the substation electrical wiring project?',
        hi: 'नमस्ते रमेश, क्या आप सबस्टेशन विद्युत तारों की परियोजना के लिए उपलब्ध हैं?',
        kn: 'ಹಲೋ ರಮೇಶ್, ನೀವು ಸಬ್‌ಸ್ಟೇಷನ್ ವಿದ್ಯುತ್ ವೈರಿಂಗ್ ಯೋಜನೆಗೆ ಲಭ್ಯವಿದ್ದೀರಾ?'
      },
      createdAt: '2026-05-23T10:00:00Z'
    },
    {
      id: 'msg-2',
      senderId: 'worker-uuid-ramesh-123', // Worker
      messageType: 'text',
      content: { text: 'Yes, sir. I have worked on similar sub-stations before.' },
      translations: {
        en: 'Yes, sir. I have worked on similar sub-stations before.',
        hi: 'हाँ, सर। मैंने पहले भी इस तरह के सब-स्टेशनों पर काम किया है।',
        kn: 'ಹೌದು, ಸರ್. ನಾನು ಈ ಹಿಂದೆ ಇದೇ ರೀತಿಯ ಸಬ್‌ಸ್ಟೇಷನ್‌ಗಳಲ್ಲಿ ಕೆಲಸ ಮಾಡಿದ್ದೇನೆ।'
      },
      createdAt: '2026-05-23T10:02:00Z'
    },
    {
      id: 'msg-3',
      senderId: 'employer-uuid-kamal-456',
      messageType: 'text',
      content: { text: 'Great, the daily wage is 750 INR. Will you be able to start tomorrow?' },
      translations: {
        en: 'Great, the daily wage is 750 INR. Will you be able to start tomorrow?',
        hi: 'बहुत बढ़िया, दैनिक वेतन 750 रुपये है। क्या आप कल से शुरू कर पाएंगे?',
        kn: 'ಉತ್ತม, ದಿನದ ಕೂಲಿ 750 ರೂ. ನಾಳೆಯಿಂದ ಕೆಲಸ ಪ್ರಾರಂಭಿಸಲು ಸಾಧ್ಯವೇ?'
      },
      createdAt: '2026-05-23T10:05:00Z'
    },
    {
      id: 'msg-4',
      senderId: 'worker-uuid-ramesh-123',
      messageType: 'text',
      content: { text: 'I can start tomorrow morning at 9 AM.' },
      translations: {
        en: 'I can start tomorrow morning at 9 AM.',
        hi: 'मैं कल सुबह 9 बजे काम शुरू कर सकता हूँ।',
        kn: 'ನಾನು ನಾಳೆ ಬೆಳಗ್ಗೆ 9 ಗಂಟೆಗೆ ಪ್ರಾರಂಭಿಸಬಹುದು.'
      },
      createdAt: '2026-05-23T10:07:00Z'
    }
  ];

  useEffect(() => {
    if (!user) {
      router.push('/');
    } else {
      setRooms(mockRooms);
      // Auto select first room
      setSelectedRoom(mockRooms[0]);
      setMessages(mockMessages);
    }
  }, [user]);

  useEffect(() => {
    // Scroll to bottom of chat
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || !selectedRoom) return;

    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      senderId: user!.id,
      messageType: 'text',
      content: { text: inputMessage },
      translations: {
        en: inputMessage,
        hi: `[अनुवादित] ${inputMessage}`,
        kn: `[ಅನುವಾದಿಸಲಾಗಿದೆ] ${inputMessage}`
      },
      createdAt: new Date().toISOString()
    };

    setMessages([...messages, newMsg]);
    setInputMessage('');
  };

  const handleSendVoiceNote = () => {
    if (!selectedRoom) return;
    setIsRecording(!isRecording);
    
    if (isRecording) {
      // Finished recording, send mock voice message
      const voiceMsg: Message = {
        id: `msg-${Date.now()}`,
        senderId: user!.id,
        messageType: 'voice',
        content: { mediaUrl: 'https://sample-audio.com/note.mp3' },
        createdAt: new Date().toISOString()
      };
      setMessages([...messages, voiceMsg]);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row h-screen overflow-hidden">
      
      {/* Sidebar: Chat Channels list */}
      <div className={`w-full md:w-80 border-r border-slate-900 flex flex-col h-full bg-slate-950 ${selectedRoom ? 'hidden md:flex' : 'flex'}`}>
        <div className="p-4 border-b border-slate-900 flex items-center gap-3">
          <button 
            onClick={() => router.push(user?.role === 'worker' ? '/dashboard/worker' : '/dashboard/employer')}
            className="p-2 hover:bg-slate-900 rounded-xl"
          >
            <ArrowLeft className="w-5 h-5 text-slate-400" />
          </button>
          <div>
            <h2 className="font-extrabold text-md text-white">CHATS & MESSAGES</h2>
            <p className="text-[10px] text-slate-500">Live AI Translation Active</p>
          </div>
        </div>

        {/* Rooms channel list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {rooms.map((room) => (
            <button
              key={room.id}
              onClick={() => setSelectedRoom(room)}
              className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center gap-3 ${
                selectedRoom?.id === room.id 
                  ? 'bg-primary-950/40 border-primary-900 shadow-md' 
                  : 'bg-slate-900/60 border-slate-850 hover:border-slate-700'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center">
                <User className="w-5 h-5 text-slate-400" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start">
                  <p className="font-bold text-sm text-slate-200 truncate">
                    {user?.role === 'worker' ? room.employerName : room.workerName}
                  </p>
                </div>
                <p className="text-xs text-primary-400 font-bold truncate mt-0.5">{room.jobTitle}</p>
                <p className="text-xs text-slate-500 truncate mt-1">{room.lastMessageText}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Chat Conversation container */}
      <div className={`flex-1 flex flex-col h-full bg-slate-950 relative ${!selectedRoom ? 'hidden md:flex items-center justify-center' : 'flex'}`}>
        {selectedRoom ? (
          <>
            {/* Active chat header */}
            <div className="p-4 border-b border-slate-900 flex items-center justify-between bg-slate-950 z-10">
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setSelectedRoom(null)} 
                  className="md:hidden p-2 hover:bg-slate-900 rounded-xl"
                >
                  <ArrowLeft className="w-5 h-5 text-slate-400" />
                </button>
                <div>
                  <h3 className="font-bold text-slate-200">
                    {user?.role === 'worker' ? selectedRoom.employerName : selectedRoom.workerName}
                  </h3>
                  <p className="text-xs text-slate-500">{selectedRoom.jobTitle}</p>
                </div>
              </div>

              {/* Translation Selection bar */}
              <div className="flex items-center gap-2 bg-slate-900 border border-slate-850 rounded-xl px-2.5 py-1.5 text-xs text-slate-400">
                <Languages className="w-4 h-4 text-primary-400" />
                <span className="font-semibold">AI Translate:</span>
                <select
                  value={translationLang}
                  onChange={(e) => setTranslationLang(e.target.value)}
                  className="bg-transparent focus:outline-none cursor-pointer text-slate-200 font-bold"
                >
                  <option value="none">Original Text</option>
                  <option value="hi">हिन्दी (Hindi)</option>
                  <option value="kn">ಕನ್ನಡ (Kannada)</option>
                  <option value="en">English</option>
                </select>
              </div>
            </div>

            {/* Message Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.map((msg) => {
                const isMe = msg.senderId === user!.id;
                
                // Determine text to show based on translation selection
                let textToShow = msg.content.text || '';
                if (translationLang !== 'none' && msg.translations && msg.translations[translationLang]) {
                  textToShow = msg.translations[translationLang];
                }

                return (
                  <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                    
                    <div className={`max-w-md rounded-2xl p-4 space-y-2 relative shadow-lg ${
                      isMe 
                        ? 'bg-primary-600 text-white rounded-tr-none' 
                        : 'bg-slate-900 border border-slate-850 text-slate-100 rounded-tl-none'
                    }`}>
                      {msg.messageType === 'text' ? (
                        <p className="text-sm leading-relaxed">{textToShow}</p>
                      ) : (
                        <div className="flex items-center gap-3 py-1">
                          <button className="w-8 h-8 rounded-full bg-slate-900/40 flex items-center justify-center text-white">
                            <Volume2 className="w-4 h-4" />
                          </button>
                          <div className="w-24 h-4 bg-slate-900/30 rounded flex items-center p-1 overflow-hidden">
                            <div className="w-full h-[2px] bg-slate-400/50 relative">
                              <div className="absolute left-0 top-0 w-2/3 h-full bg-white rounded" />
                            </div>
                          </div>
                          <span className="text-[10px] text-slate-400">Audio note</span>
                        </div>
                      )}

                      <div className="flex justify-between items-center gap-4 text-[9px] text-slate-400 pt-1">
                        <span>{new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        {isMe && (
                          <span className="text-emerald-400 flex items-center gap-0.5">
                            <CheckCheck className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </div>
                    </div>

                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Bar */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-900 bg-slate-950 flex items-center gap-3">
              <div className="flex gap-1.5 shrink-0">
                <button
                  type="button"
                  className="p-3 bg-slate-900 border border-slate-850 rounded-xl text-slate-400 hover:text-slate-200 transition-all"
                  title="Upload Image"
                >
                  <Image className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={handleSendVoiceNote}
                  className={`p-3 border rounded-xl transition-all ${
                    isRecording 
                      ? 'bg-rose-500 border-rose-400 text-white animate-pulse' 
                      : 'bg-slate-900 border-slate-850 text-slate-400 hover:text-slate-200'
                  }`}
                  title="Record Voice Note"
                >
                  <Mic className="w-5 h-5" />
                </button>
              </div>

              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 bg-slate-900 border border-slate-850 rounded-xl py-3 px-4 text-sm focus:outline-none focus:border-primary-500"
              />

              <button
                type="submit"
                className="p-3 bg-gradient-premium text-white rounded-xl shadow-md hover:brightness-110"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </>
        ) : (
          <div className="text-center space-y-4 p-8">
            <Sparkles className="w-12 h-12 text-primary-400 mx-auto opacity-30" />
            <h4 className="font-bold text-slate-500">No Chat Selected</h4>
            <p className="text-xs text-slate-600">Select a conversation from the sidebar channel list to begin.</p>
          </div>
        )}
      </div>

    </div>
  );
}
