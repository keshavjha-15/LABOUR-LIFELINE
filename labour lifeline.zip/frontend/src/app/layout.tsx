import type { Metadata } from "next";
import "./globals.css";
import { LanguageProvider } from "@/context/LanguageContext";
import { AuthProvider } from "@/context/AuthContext";

export const metadata: Metadata = {
  title: "Labour Platform - AI-Powered Workforce Hiring System",
  description: "A complete production-level, AI-powered platform connecting skilled and unskilled workers with employers, daily wage jobs, and local services.",
  keywords: ["hiring", "skilled labour", "unskilled labour", "blue collar", "workers", "electrician", "plumber", "AI matching", "payments", "escrow"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased min-h-screen bg-background text-foreground">
        <AuthProvider>
          <LanguageProvider>
            {children}
          </LanguageProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
