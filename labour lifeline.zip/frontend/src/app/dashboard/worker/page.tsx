'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import { useRouter } from 'next/navigation';
import { 
  Sparkles, MapPin, Phone, HelpCircle, BookOpen, 
  Wallet, Award, LogOut, CheckCircle2, Mic, MicOff, Search, Play, HelpCircle as HelpIcon
} from 'lucide-react';

interface Job {
  id: string;
  title: string;
  company_name: string;
  description: string;
  salary_wage: number;
  distance_km: number;
  job_type: string;
  required_skills: string[];
  match_score?: number;
  food_provided: boolean;
  applied?: boolean;
}

export default function WorkerDashboard() {
  const { user, logout } = useAuth();
  const { t, language } = useLanguage();
  const router = useRouter();

  const [activeTab, setActiveTab] = useState<'jobs' | 'payments' | 'training'>('jobs');
  const [jobs, setJobs] = useState<Job[]>([]);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Skill verification quiz states
  const [quizScore, setQuizScore] = useState<number | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [verifiedBadge, setVerifiedBadge] = useState(false);

  // Payments mock data
  const mockPayments = [
    { id: 'pay-1', job_title: 'Electrician for Shop Rewiring', employer: 'Koramangala Stores', amount: 750.00, status: 'released', date: '2026-05-20' },
    { id: 'pay-2', job_title: 'Apartment Substation Connection', employer: 'Kamal Builders Ltd', amount: 1500.00, status: 'escrowed', date: '2026-05-22' }
  ];

  // Initial mockup jobs
  const initialJobs: Job[] = [
    {
      id: 'job-1',
      title: 'Urgent Substation Electrician',
      company_name: 'Kamal Builders Ltd',
      description: 'Need a certified electrician to link meters and install primary cables in a residential project.',
      salary_wage: 750.00,
      distance_km: 1.2,
      job_type: 'emergency',
      required_skills: ['Electrician'],
      match_score: 95,
      food_provided: true
    },
    {
      id: 'job-2',
      title: 'House Paint Project',
      company_name: 'Rajesh Patel',
      description: 'Required 3 skilled painters for a villa interior painting project. Paint and brush tools provided.',
      salary_wage: 550.00,
      distance_km: 3.8,
      job_type: 'contract',
      required_skills: ['Painter'],
      match_score: 82,
      food_provided: false
    },
    {
      id: 'job-3',
      title: 'Commercial Driver Needed',
      company_name: 'Anand Logistics',
      description: 'Need experienced driver with commercial licence for cargo deliveries across Bangalore.',
      salary_wage: 800.00,
      distance_km: 5.0,
      job_type: 'full-time',
      required_skills: ['Driver'],
      match_score: 70,
      food_provided: true
    }
  ];

  useEffect(() => {
    // Check authentication
    if (!user) {
      router.push('/');
    } else {
      setJobs(initialJobs);
    }
  }, [user]);

  const handleApply = (jobId: string) => {
    setJobs(jobs.map(j => j.id === jobId ? { ...j, applied: true } : j));
  };

  // Simulate Voice Command Endpoint
  const startVoiceListen = () => {
    setIsListening(true);
    setVoiceTranscript('Listening...');

    // Simulate speech-to-text transcription delay
    setTimeout(() => {
      const voicePrompts = [
        "Find electrician jobs near me",
        "Mujhe painting ka kaam chahiye",
        "Find driver work in Bangalore"
      ];
      const randomPrompt = voicePrompts[Math.floor(Math.random() * voicePrompts.length)];
      setVoiceTranscript(randomPrompt);
      setIsListening(false);
      
      // Parse query and filter jobs
      if (randomPrompt.toLowerCase().includes('electrician')) {
        setSearchTerm('electrician');
        setJobs(initialJobs.filter(j => j.required_skills.includes('Electrician')));
      } else if (randomPrompt.toLowerCase().includes('paint')) {
        setSearchTerm('paint');
        setJobs(initialJobs.filter(j => j.required_skills.includes('Painter')));
      } else if (randomPrompt.toLowerCase().includes('driver')) {
        setSearchTerm('driver');
        setJobs(initialJobs.filter(j => j.required_skills.includes('Driver')));
      }
    }, 2000);
  };

  // Quiz helper
  const handleQuizSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let score = 0;
    if (selectedAnswers[0] === 'Ground/Earth') score += 50;
    if (selectedAnswers[1] === 'Multimeter') score += 50;
    
    setQuizScore(score);
    if (score === 100) {
      setVerifiedBadge(true);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Header bar */}
      <header className="glass-panel border-b border-slate-900 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-premium flex items-center justify-center shadow-lg">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-extrabold text-lg leading-none text-white">WORKER DASHBOARD</h1>
            <p className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              {verifiedBadge ? 'NSDC Certified Expert' : 'Aadhaar Verified'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-slate-200">{user?.fullName}</p>
            <p className="text-xs text-slate-500">{user?.phoneNumber}</p>
          </div>
          <button 
            onClick={() => {
              logout();
              router.push('/');
            }}
            className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-slate-400 hover:text-rose-400 hover:border-rose-950 transition-all"
            title={t('logout')}
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main content grid */}
      <div className="flex-1 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-8 px-6 py-8">
        
        {/* Left Side: Voice Assistant & Search Panel */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Audio voice assistance system */}
          <div className="glass-panel border border-slate-850 rounded-2xl p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-rose-500/5 rounded-full blur-xl pointer-events-none" />
            
            <h3 className="text-md font-bold text-slate-200 mb-3 flex items-center gap-2">
              <Mic className="w-4 h-4 text-rose-400" />
              {t('voice_assistant')} (Multilingual)
            </h3>
            
            <p className="text-xs text-slate-400 mb-4">
              Click the microphone and say what job you are looking for in your language.
            </p>

            <div className="flex flex-col items-center justify-center p-4 bg-slate-900/60 border border-slate-800 rounded-xl mb-4 text-center">
              <button
                onClick={startVoiceListen}
                className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
                  isListening 
                    ? 'bg-rose-500 text-white animate-ping' 
                    : 'bg-rose-950/40 border border-rose-900 text-rose-400 hover:bg-rose-900/30'
                }`}
              >
                {isListening ? <MicOff className="w-6 h-6 animate-pulse" /> : <Mic className="w-6 h-6" />}
              </button>
              
              <p className="text-xs font-semibold text-slate-300 mt-4 h-5">
                {voiceTranscript || t('voice_placeholder')}
              </p>
            </div>

            <div className="flex flex-wrap gap-1.5 justify-center">
              <span className="text-[10px] text-slate-500 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full">English</span>
              <span className="text-[10px] text-slate-500 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full">हिन्दी</span>
              <span className="text-[10px] text-slate-500 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full">ಕನ್ನಡ</span>
              <span className="text-[10px] text-slate-500 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full">தமிழ்</span>
            </div>
          </div>

          {/* Quick Stats Panel */}
          <div className="glass-panel border border-slate-850 rounded-2xl p-6">
            <h3 className="text-md font-bold text-slate-200 mb-4 flex items-center gap-2">
              <Wallet className="w-4 h-4 text-primary-400" />
              Wage Summary
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-900/50 border border-slate-850 rounded-xl">
                <p className="text-xs text-slate-500">Escrow Locked</p>
                <p className="text-xl font-bold text-amber-400 mt-1">₹1,500</p>
              </div>

              <div className="p-4 bg-slate-900/50 border border-slate-850 rounded-xl">
                <p className="text-xs text-slate-500">Total Earned</p>
                <p className="text-xl font-bold text-emerald-400 mt-1">₹12,400</p>
              </div>
            </div>
          </div>

          {/* SOS Panel */}
          <div className="p-5 rounded-2xl bg-rose-950/20 border border-rose-900/60 relative overflow-hidden">
            <h4 className="text-sm font-bold text-rose-300 flex items-center gap-2 mb-2">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
              </span>
              Emergency Work Alerts
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Employers near you are requesting emergency services. Toggle your availability status to get instant SMS jobs.
            </p>
            <button className="w-full mt-4 py-2.5 bg-rose-600 hover:bg-rose-500 transition-all font-bold text-white text-xs rounded-xl shadow-lg shadow-rose-950">
              Go Available for Emergency
            </button>
          </div>
        </div>

        {/* Right Side: Tab Interface & Jobs List */}
        <div className="lg:col-span-8 space-y-6">
          {/* Navigation tabs */}
          <div className="flex border-b border-slate-850">
            <button
              onClick={() => setActiveTab('jobs')}
              className={`pb-4 px-6 font-bold text-sm transition-all flex items-center gap-2 border-b-2 ${
                activeTab === 'jobs' 
                  ? 'border-primary-500 text-primary-400' 
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Search className="w-4 h-4" />
              {t('jobs_near_me')}
            </button>

            <button
              onClick={() => setActiveTab('payments')}
              className={`pb-4 px-6 font-bold text-sm transition-all flex items-center gap-2 border-b-2 ${
                activeTab === 'payments' 
                  ? 'border-primary-500 text-primary-400' 
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Wallet className="w-4 h-4" />
              {t('payments')}
            </button>

            <button
              onClick={() => setActiveTab('training')}
              className={`pb-4 px-6 font-bold text-sm transition-all flex items-center gap-2 border-b-2 ${
                activeTab === 'training' 
                  ? 'border-primary-500 text-primary-400' 
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              {t('courses')}
            </button>
          </div>

          {/* TAB 1: Jobs List */}
          {activeTab === 'jobs' && (
            <div className="space-y-4">
              
              {/* Job filter bar */}
              <div className="relative">
                <input
                  type="text"
                  placeholder={t('search_placeholder')}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-850 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-primary-500"
                />
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              </div>

              {jobs.map((job) => (
                <div 
                  key={job.id} 
                  className="glass-panel border border-slate-850 hover:border-primary-800 transition-all rounded-2xl p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-6"
                >
                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-lg font-bold text-slate-100">{job.title}</h4>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-primary-950 border border-primary-900 text-primary-400">
                        {job.job_type.toUpperCase()}
                      </span>
                      {job.match_score && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-900 text-emerald-400 flex items-center gap-1">
                          <Sparkles className="w-3 h-3" />
                          {job.match_score}% AI Match
                        </span>
                      )}
                    </div>

                    <p className="text-xs font-bold text-slate-400">{job.company_name}</p>
                    <p className="text-xs text-slate-500 max-w-xl">{job.description}</p>
                    
                    <div className="flex flex-wrap gap-4 text-xs text-slate-400 pt-2">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-rose-500" />
                        {job.distance_km} km away
                      </span>
                      <span className="flex items-center gap-1 font-bold text-slate-300">
                        ₹ {job.salary_wage} / Daily
                      </span>
                      {job.food_provided && (
                        <span className="text-emerald-400">✔ Food & Lodge Provided</span>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-2 w-full md:w-auto">
                    <button 
                      onClick={() => router.push('/chat')}
                      className="flex-1 md:flex-none px-4 py-3 bg-slate-900 border border-slate-800 text-slate-300 rounded-xl hover:bg-slate-850 font-bold text-xs"
                    >
                      Chat
                    </button>
                    <button
                      onClick={() => handleApply(job.id)}
                      disabled={job.applied}
                      className={`flex-1 md:flex-none px-5 py-3 rounded-xl font-bold text-xs transition-all ${
                        job.applied 
                          ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
                          : 'bg-gradient-premium text-white hover:brightness-110 shadow-md shadow-primary-500/10'
                      }`}
                    >
                      {job.applied ? t('applied') : t('apply_now')}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 2: Payments History */}
          {activeTab === 'payments' && (
            <div className="glass-panel border border-slate-850 rounded-2xl overflow-hidden">
              <div className="p-6 border-b border-slate-850">
                <h4 className="font-bold text-slate-100">Transaction History</h4>
                <p className="text-xs text-slate-500">Track your daily wage payout statements and invoice copies.</p>
              </div>

              <div className="divide-y divide-slate-850">
                {mockPayments.map((p) => (
                  <div key={p.id} className="p-6 flex justify-between items-center">
                    <div>
                      <p className="text-sm font-bold text-slate-200">{p.job_title}</p>
                      <p className="text-xs text-slate-500">From: {p.employer} | Date: {p.date}</p>
                    </div>

                    <div className="text-right">
                      <p className="text-sm font-extrabold text-slate-200">₹ {p.amount}</p>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full inline-block mt-1 ${
                        p.status === 'released' 
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-900' 
                          : 'bg-amber-950/60 text-amber-400 border border-amber-900'
                      }`}>
                        {p.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: Skill Training & Certifications */}
          {activeTab === 'training' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Course player */}
              <div className="glass-panel border border-slate-850 rounded-2xl p-6 space-y-4">
                <div className="relative aspect-video rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center overflow-hidden">
                  <Play className="w-12 h-12 text-primary-400 hover:scale-110 cursor-pointer transition-all" />
                  <p className="absolute bottom-3 left-4 text-xs font-semibold text-slate-200">Basic Electrical Safety Video</p>
                </div>
                
                <div>
                  <h4 className="font-bold text-slate-100">Basic Electrical Safety</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Learn about grounding, circuit testers, and protective gear required for industrial wiring.
                  </p>
                </div>
              </div>

              {/* Certification Quiz */}
              <div className="glass-panel border border-slate-850 rounded-2xl p-6">
                <h4 className="font-bold text-slate-100 mb-3 flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-400" />
                  NSDC Certification Quiz
                </h4>
                
                {quizScore === 100 ? (
                  <div className="text-center py-8 space-y-3">
                    <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                    <p className="font-bold text-slate-100">Quiz Completed! Score: 100%</p>
                    <p className="text-xs text-slate-400">
                      Congratulations! You have received your verified credential badge.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleQuizSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <p className="text-xs font-bold text-slate-300">1. What does a green wire insulation represent?</p>
                      <div className="grid grid-cols-1 gap-2">
                        {['Phase/Live', 'Neutral', 'Ground/Earth'].map((opt) => (
                          <label key={opt} className="flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 p-2.5 rounded-xl cursor-pointer hover:bg-slate-850">
                            <input
                              type="radio"
                              name="q1"
                              value={opt}
                              onChange={() => setSelectedAnswers({ ...selectedAnswers, 0: opt })}
                              className="accent-primary-500"
                            />
                            {opt}
                          </label>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <p className="text-xs font-bold text-slate-300">2. Which instrument checks voltage?</p>
                      <div className="grid grid-cols-1 gap-2">
                        {['Ammeter', 'Multimeter', 'Odometer'].map((opt) => (
                          <label key={opt} className="flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 p-2.5 rounded-xl cursor-pointer hover:bg-slate-850">
                            <input
                              type="radio"
                              name="q2"
                              value={opt}
                              onChange={() => setSelectedAnswers({ ...selectedAnswers, 1: opt })}
                              className="accent-primary-500"
                            />
                            {opt}
                          </label>
                        ))}
                      </div>
                    </div>

                    {quizScore !== null && quizScore < 100 && (
                      <p className="text-xs text-rose-400 font-semibold">Failed! Please try again to unlock your badge.</p>
                    )}

                    <button
                      type="submit"
                      className="w-full py-3 bg-gradient-premium text-white font-bold text-xs rounded-xl"
                    >
                      Submit Quiz for Evaluation
                    </button>
                  </form>
                )}
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
