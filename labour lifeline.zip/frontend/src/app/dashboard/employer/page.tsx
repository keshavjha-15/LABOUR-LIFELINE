'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import { useRouter } from 'next/navigation';
import { 
  Sparkles, PlusCircle, CheckCircle, Clock, Wallet, Users, 
  MapPin, LogOut, CheckCircle2, ChevronRight, XCircle, AlertCircle, BarChart3
} from 'lucide-react';

interface Applicant {
  id: string;
  name: string;
  skill: string;
  wage: number;
  match_score: number;
  phone: string;
  status: 'pending' | 'hired' | 'rejected';
}

interface PostedJob {
  id: string;
  title: string;
  type: string;
  wage: number;
  needed: number;
  hired: number;
  applicants: Applicant[];
  status: 'active' | 'completed';
}

export default function EmployerDashboard() {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const router = useRouter();

  const [activeTab, setActiveTab] = useState<'manage' | 'post' | 'analytics'>('manage');
  const [postedJobs, setPostedJobs] = useState<PostedJob[]>([]);
  const [hiringAlert, setHiringAlert] = useState('');

  // Post Job form state
  const [jobTitle, setJobTitle] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [jobType, setJobType] = useState('daily-wage');
  const [jobWage, setJobWage] = useState('600');
  const [workersNeeded, setWorkersNeeded] = useState('2');
  const [requiredSkills, setRequiredSkills] = useState('Electrician');
  const [jobAddress, setJobAddress] = useState('');

  const initialPostedJobs: PostedJob[] = [
    {
      id: 'post-1',
      title: 'Urgent Substation Electrician',
      type: 'emergency',
      wage: 750.00,
      needed: 2,
      hired: 0,
      status: 'active',
      applicants: [
        { id: 'app-1', name: 'Ramesh Kumar', skill: 'Electrician', wage: 600.00, match_score: 95, phone: '+919876543210', status: 'pending' },
        { id: 'app-2', name: 'Anil Sharma', skill: 'Electrician', wage: 800.00, match_score: 74, phone: '+919876543212', status: 'pending' }
      ]
    },
    {
      id: 'post-2',
      title: 'House Painting Project',
      type: 'contract',
      wage: 550.00,
      needed: 3,
      hired: 1,
      status: 'active',
      applicants: [
        { id: 'app-3', name: 'Suresh Prasad', skill: 'Painter', wage: 500.00, match_score: 82, phone: '+919876543211', status: 'hired' }
      ]
    }
  ];

  useEffect(() => {
    if (!user) {
      router.push('/');
    } else {
      setPostedJobs(initialPostedJobs);
    }
  }, [user]);

  // Post job handler
  const handlePostJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!jobTitle || !jobDescription || !jobAddress) {
      setHiringAlert('Please fill in all required fields.');
      return;
    }

    const newJob: PostedJob = {
      id: `post-${Date.now()}`,
      title: jobTitle,
      type: jobType,
      wage: parseFloat(jobWage),
      needed: parseInt(workersNeeded),
      hired: 0,
      status: 'active',
      applicants: []
    };

    setPostedJobs([newJob, ...postedJobs]);
    setHiringAlert('Job posted successfully! Nearby workers have been alerted.');
    
    // Clear form
    setJobTitle('');
    setJobDescription('');
    setJobAddress('');
    
    setTimeout(() => {
      setHiringAlert('');
      setActiveTab('manage');
    }, 1500);
  };

  // Hire handler
  const handleHire = (jobId: string, applicantId: string) => {
    setPostedJobs(postedJobs.map(job => {
      if (job.id === jobId) {
        const updatedApplicants = job.applicants.map(app => {
          if (app.id === applicantId) {
            return { ...app, status: 'hired' as const };
          }
          return app;
        });
        const hiredCount = updatedApplicants.filter(a => a.status === 'hired').length;
        return { ...job, applicants: updatedApplicants, hired: hiredCount };
      }
      return job;
    }));

    setHiringAlert('Worker hired! Escrow payment has been successfully secured.');
    setTimeout(() => setHiringAlert(''), 3000);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Header bar */}
      <header className="glass-panel border-b border-slate-900 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-premium flex items-center justify-center shadow-lg">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-extrabold text-lg leading-none text-white">EMPLOYER DASHBOARD</h1>
            <p className="text-[10px] text-primary-400 font-bold uppercase tracking-wider mt-1">
              {user?.fullName} | Corporate Account
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => {
              logout();
              router.push('/');
            }}
            className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-slate-400 hover:text-rose-400 hover:border-rose-950 transition-all"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main content grid */}
      <div className="flex-1 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-8 px-6 py-8">
        
        {/* Left Side: Actions & Mini Stats */}
        <div className="lg:col-span-4 space-y-6">
          <div className="glass-panel border border-slate-850 rounded-2xl p-6 space-y-4">
            <button
              onClick={() => setActiveTab('post')}
              className={`w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                activeTab === 'post' 
                  ? 'bg-gradient-premium text-white shadow-lg' 
                  : 'bg-primary-950/20 border border-primary-900 text-primary-400 hover:bg-primary-950/40'
              }`}
            >
              <PlusCircle className="w-5 h-5" />
              {t('post_job')}
            </button>

            <button
              onClick={() => setActiveTab('manage')}
              className={`w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                activeTab === 'manage' 
                  ? 'bg-gradient-premium text-white shadow-lg' 
                  : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-850'
              }`}
            >
              <Users className="w-5 h-5" />
              {t('hiring_manager')}
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                activeTab === 'analytics' 
                  ? 'bg-gradient-premium text-white shadow-lg' 
                  : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-850'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              {t('analytics')}
            </button>
          </div>

          {/* Quick Metrics */}
          <div className="glass-panel border border-slate-850 rounded-2xl p-6 space-y-6">
            <h4 className="font-bold text-slate-200">Payment Escrow Desk</h4>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Active Escrow Locked</span>
                <span className="font-bold text-amber-400">₹4,500</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Transferred Today</span>
                <span className="font-bold text-emerald-400">₹2,200</span>
              </div>
              <div className="h-[1px] bg-slate-900" />
              <div className="p-3 bg-emerald-950/20 border border-emerald-900/60 rounded-xl flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                <p className="text-[10px] text-slate-400 leading-normal">
                  All contracts use **Razorpay/Stripe protected escrow**. Workers are paid automatically when work completion coordinates are verified.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Tab Panel Views */}
        <div className="lg:col-span-8 space-y-6">
          {hiringAlert && (
            <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-900 text-emerald-400 text-xs flex items-center gap-2 animate-pulse">
              <CheckCircle className="w-5 h-5" />
              {hiringAlert}
            </div>
          )}

          {/* TAB 1: Manage Active Jobs */}
          {activeTab === 'manage' && (
            <div className="space-y-6">
              {postedJobs.map((job) => (
                <div key={job.id} className="glass-panel border border-slate-850 rounded-2xl p-6 space-y-6">
                  
                  {/* Job Header */}
                  <div className="flex flex-wrap justify-between items-center gap-2 border-b border-slate-850 pb-4">
                    <div>
                      <h4 className="text-lg font-bold text-slate-100">{job.title}</h4>
                      <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                        <span className="uppercase text-primary-400 font-bold">{job.type}</span>
                        <span>•</span>
                        <span>₹{job.wage}/Daily</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="text-xs text-slate-500">Workers Needed</p>
                      <p className="text-md font-extrabold text-slate-200">
                        {job.hired} / {job.needed} Filled
                      </p>
                    </div>
                  </div>

                  {/* Applicants List */}
                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Applicants</h5>
                    
                    {job.applicants.length === 0 ? (
                      <p className="text-xs text-slate-500">Awaiting applications... Matches have been alerted nearby.</p>
                    ) : (
                      <div className="space-y-3">
                        {job.applicants.map((app) => (
                          <div key={app.id} className="p-4 bg-slate-900/50 border border-slate-850 rounded-xl flex flex-wrap justify-between items-center gap-4">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-bold text-slate-200">{app.name}</span>
                                <span className="text-[10px] font-bold bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                                  <Sparkles className="w-2.5 h-2.5" />
                                  {app.match_score}% Match
                                </span>
                              </div>
                              <p className="text-xs text-slate-500 mt-1">Skill: {app.skill} | Bid: ₹{app.wage}/day</p>
                            </div>

                            <div className="flex items-center gap-2">
                              <button 
                                onClick={() => router.push('/chat')}
                                className="px-3.5 py-2 bg-slate-800 border border-slate-700 text-slate-300 font-bold text-xs rounded-xl hover:bg-slate-750"
                              >
                                Chat
                              </button>

                              {app.status === 'hired' ? (
                                <span className="px-3.5 py-2 bg-emerald-950/60 border border-emerald-900 text-emerald-400 font-bold text-xs rounded-xl flex items-center gap-1">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  Hired & Escrowed
                                </span>
                              ) : (
                                <button
                                  onClick={() => handleHire(job.id, app.id)}
                                  className="px-4 py-2 bg-gradient-premium text-white font-bold text-xs rounded-xl hover:brightness-110"
                                >
                                  Approve & Hire
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                </div>
              ))}
            </div>
          )}

          {/* TAB 2: Post a Job Form */}
          {activeTab === 'post' && (
            <div className="glass-panel border border-slate-850 rounded-2xl p-8">
              <h3 className="text-xl font-bold text-slate-100 mb-6">Create New Job Posting</h3>
              
              <form onSubmit={handlePostJob} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <label className="block space-y-2">
                    <span className="text-xs font-semibold text-slate-400 uppercase">Job Title</span>
                    <input
                      type="text"
                      value={jobTitle}
                      onChange={(e) => setJobTitle(e.target.value)}
                      placeholder="E.g., Urgent Substation Electrician"
                      className="w-full bg-slate-900 border border-slate-850 rounded-xl py-3 px-4 focus:ring-1 focus:ring-primary-500 focus:outline-none text-slate-100"
                    />
                  </label>

                  <label className="block space-y-2">
                    <span className="text-xs font-semibold text-slate-400 uppercase">Job Category / Skill</span>
                    <select
                      value={requiredSkills}
                      onChange={(e) => setRequiredSkills(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-855 rounded-xl py-3 px-4 focus:outline-none text-slate-100"
                    >
                      <option value="Electrician">Electrician</option>
                      <option value="Plumber">Plumber</option>
                      <option value="Carpenter">Carpenter</option>
                      <option value="Painter">Painter</option>
                      <option value="Driver">Driver</option>
                      <option value="Construction Worker">Construction Worker</option>
                    </select>
                  </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <label className="block space-y-2">
                    <span className="text-xs font-semibold text-slate-400 uppercase">Job Type</span>
                    <select
                      value={jobType}
                      onChange={(e) => setJobType(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-855 rounded-xl py-3 px-4 focus:outline-none text-slate-100"
                    >
                      <option value="daily-wage">Daily Wage</option>
                      <option value="emergency">Emergency / Instant</option>
                      <option value="contract">Contract Project</option>
                      <option value="full-time">Full-Time Job</option>
                    </select>
                  </label>

                  <label className="block space-y-2">
                    <span className="text-xs font-semibold text-slate-400 uppercase">Daily Wage (INR)</span>
                    <input
                      type="number"
                      value={jobWage}
                      onChange={(e) => setJobWage(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-850 rounded-xl py-3 px-4 focus:outline-none text-slate-100"
                    />
                  </label>

                  <label className="block space-y-2">
                    <span className="text-xs font-semibold text-slate-400 uppercase">Workers Needed</span>
                    <input
                      type="number"
                      value={workersNeeded}
                      onChange={(e) => setWorkersNeeded(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-850 rounded-xl py-3 px-4 focus:outline-none text-slate-100"
                    />
                  </label>
                </div>

                <label className="block space-y-2">
                  <span className="text-xs font-semibold text-slate-400 uppercase">Job Location Address</span>
                  <input
                    type="text"
                    value={jobAddress}
                    onChange={(e) => setJobAddress(e.target.value)}
                    placeholder="E.g., Sector 4, HSR Layout, Bangalore"
                    className="w-full bg-slate-900 border border-slate-850 rounded-xl py-3 px-4 focus:outline-none text-slate-100"
                  />
                </label>

                <label className="block space-y-2">
                  <span className="text-xs font-semibold text-slate-400 uppercase">Detailed Description & Schedule</span>
                  <textarea
                    rows={4}
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    placeholder="Provide details about expectations, safety materials, timing, food, and accommodation..."
                    className="w-full bg-slate-900 border border-slate-850 rounded-xl py-3 px-4 focus:outline-none text-slate-100"
                  />
                </label>

                <button
                  type="submit"
                  className="w-full py-4 bg-gradient-premium text-white font-bold rounded-xl shadow-lg shadow-primary-500/25 hover:brightness-110 active:scale-[0.98] transition-all"
                >
                  Publish & Broadcast Job Post
                </button>
              </form>
            </div>
          )}

          {/* TAB 3: Analytics Dashboard */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              
              {/* Mini cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="glass-panel border border-slate-850 rounded-2xl p-5">
                  <p className="text-xs text-slate-500">Total Hires</p>
                  <p className="text-2xl font-extrabold text-white mt-1">14 Workers</p>
                </div>
                <div className="glass-panel border border-slate-850 rounded-2xl p-5">
                  <p className="text-xs text-slate-500">Active Jobs</p>
                  <p className="text-2xl font-extrabold text-white mt-1">2 Active</p>
                </div>
                <div className="glass-panel border border-slate-850 rounded-2xl p-5">
                  <p className="text-xs text-slate-500">Expenditure</p>
                  <p className="text-2xl font-extrabold text-emerald-400 mt-1">₹42,800</p>
                </div>
              </div>

              {/* SVG Charts representation */}
              <div className="glass-panel border border-slate-850 rounded-2xl p-6">
                <h4 className="font-bold text-slate-200 mb-6">Expenditure Trend (Last 5 Months)</h4>
                
                {/* SVG Line Chart */}
                <div className="h-64 w-full bg-slate-900/50 border border-slate-850 rounded-xl flex items-center justify-center p-4">
                  <svg className="w-full h-full" viewBox="0 0 500 200">
                    {/* Grid lines */}
                    <line x1="40" y1="20" x2="480" y2="20" stroke="#1e293b" strokeDasharray="4 4" />
                    <line x1="40" y1="80" x2="480" y2="80" stroke="#1e293b" strokeDasharray="4 4" />
                    <line x1="40" y1="140" x2="480" y2="140" stroke="#1e293b" strokeDasharray="4 4" />
                    <line x1="40" y1="170" x2="480" y2="170" stroke="#1e293b" />

                    {/* Chart labels */}
                    <text x="35" y="25" fill="#64748b" fontSize="10" textAnchor="end">₹10K</text>
                    <text x="35" y="85" fill="#64748b" fontSize="10" textAnchor="end">₹5K</text>
                    <text x="35" y="145" fill="#64748b" fontSize="10" textAnchor="end">₹1K</text>
                    <text x="35" y="175" fill="#64748b" fontSize="10" textAnchor="end">0</text>

                    {/* Month labels */}
                    <text x="80" y="190" fill="#64748b" fontSize="10" textAnchor="middle">Jan</text>
                    <text x="160" y="190" fill="#64748b" fontSize="10" textAnchor="middle">Feb</text>
                    <text x="240" y="190" fill="#64748b" fontSize="10" textAnchor="middle">Mar</text>
                    <text x="320" y="190" fill="#64748b" fontSize="10" textAnchor="middle">Apr</text>
                    <text x="400" y="190" fill="#64748b" fontSize="10" textAnchor="middle">May</text>

                    {/* Data line */}
                    <path
                      d="M 80 160 L 160 120 L 240 70 L 320 100 L 400 40"
                      fill="none"
                      stroke="#4f73ff"
                      strokeWidth="3"
                      strokeLinecap="round"
                    />

                    {/* Data points */}
                    <circle cx="80" cy="160" r="5" fill="#1e3a8a" stroke="#4f73ff" strokeWidth="2" />
                    <circle cx="160" cy="120" r="5" fill="#1e3a8a" stroke="#4f73ff" strokeWidth="2" />
                    <circle cx="240" cy="70" r="5" fill="#1e3a8a" stroke="#4f73ff" strokeWidth="2" />
                    <circle cx="320" cy="100" r="5" fill="#1e3a8a" stroke="#4f73ff" strokeWidth="2" />
                    <circle cx="400" cy="40" r="5" fill="#1e3a8a" stroke="#4f73ff" strokeWidth="2" />
                  </svg>
                </div>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
