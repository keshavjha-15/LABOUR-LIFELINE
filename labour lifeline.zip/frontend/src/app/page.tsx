'use client';

import React, { useState } from 'react';
import { useLanguage, LanguageCode } from '@/context/LanguageContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import { 
  ShieldCheck, Phone, UserCheck, Briefcase, Award, Languages, 
  MapPin, Sparkles, MessageSquare, AlertCircle, PlayCircle 
} from 'lucide-react';

export default function LandingPage() {
  const { t, language, setLanguage } = useLanguage();
  const { login, register, isAuthenticated } = useAuth();
  const router = useRouter();

  // Registration & Login Simulation state
  const [selectedRole, setSelectedRole] = useState<'worker' | 'employer'>('worker');
  const [step, setStep] = useState<'role' | 'phone' | 'otp' | 'details' | 'success'>('role');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [fullName, setFullName] = useState('');
  const [skillsSelected, setSkillsSelected] = useState<string[]>([]);
  const [dailyWage, setDailyWage] = useState('500');
  const [sentOtp, setSentOtp] = useState('');

  const [message, setMessage] = useState('');

  const languagesList: { code: LanguageCode; label: string }[] = [
    { code: 'en', label: 'English' },
    { code: 'hi', label: 'हिन्दी' },
    { code: 'kn', label: 'ಕನ್ನಡ' },
    { code: 'ta', label: 'தமிழ்' },
    { code: 'te', label: 'తెలుగు' },
    { code: 'bn', label: 'বাংলা' },
    { code: 'mr', label: 'मराठी' },
    { code: 'ur', label: 'اردو' }
  ];

  const popularSkills = [
    'Electrician', 'Plumber', 'Carpenter', 'Driver', 
    'Welder', 'Painter', 'Security Guard', 'Construction Worker'
  ];

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || phoneNumber.length < 10) {
      setMessage('Please enter a valid phone number.');
      return;
    }
    // Simulate OTP generation
    const generated = Math.floor(100000 + Math.random() * 900000).toString();
    setSentOtp(generated);
    setMessage(`[MOCK SMS] OTP code sent: ${generated}`);
    setStep('otp');
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp !== sentOtp) {
      setMessage('Incorrect OTP code. Please look at the notification bar.');
      return;
    }
    setMessage('');
    setStep('details');
  };

  const handleCompleteRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName) {
      setMessage('Full name is required.');
      return;
    }
    
    await register(fullName, phoneNumber, selectedRole, {
      skills: skillsSelected,
      wage: dailyWage
    });

    setStep('success');
    setTimeout(() => {
      if (selectedRole === 'worker') {
        router.push('/dashboard/worker');
      } else {
        router.push('/dashboard/employer');
      }
    }, 1500);
  };

  const toggleSkill = (skill: string) => {
    if (skillsSelected.includes(skill)) {
      setSkillsSelected(skillsSelected.filter(s => s !== skill));
    } else {
      setSkillsSelected([...skillsSelected, skill]);
    }
  };

  return (
    <div className="relative min-h-screen bg-slate-950 text-slate-100 overflow-hidden">
      {/* Background Gradients & Accents */}
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-primary-600/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-600/10 blur-[120px] pointer-events-none" />

      {/* Header bar */}
      <header className="sticky top-0 z-50 glass-panel border-b border-slate-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-premium flex items-center justify-center shadow-lg shadow-primary-500/20">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-primary-400 to-primary-200 bg-clip-text text-transparent">
              ANTIGRAVITY LABOUR
            </h1>
            <p className="text-[10px] text-slate-400 tracking-widest uppercase">AI WORKFORCE SYSTEM</p>
          </div>
        </div>

        {/* Language Selection menu */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-300">
            <Languages className="w-4 h-4 text-primary-400 mr-1" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as LanguageCode)}
              className="bg-transparent focus:outline-none cursor-pointer pr-1"
            >
              {languagesList.map((lang) => (
                <option key={lang.code} value={lang.code} className="bg-slate-950 text-slate-100">
                  {lang.label}
                </option>
              ))}
            </select>
          </div>

          <button 
            onClick={() => {
              // Standard quick login
              login('+919876543210', 'worker');
              router.push('/dashboard/worker');
            }} 
            className="hidden sm:inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-primary-400 bg-primary-950/40 border border-primary-900 rounded-xl hover:bg-primary-900/40 transition-all"
          >
            Demo Quick Login
          </button>
        </div>
      </header>

      {/* Main Grid Content */}
      <main className="max-w-7xl mx-auto px-6 py-12 lg:py-20 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Left Side: Marketing & Pitch */}
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-900/30 border border-primary-800 text-xs text-primary-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Aadhaar verified & Escrow protected workspace
          </div>
          
          <h2 className="text-4xl md:text-6xl font-extrabold tracking-tight leading-[1.1] text-white">
            {t('app_title')}
          </h2>
          
          <p className="text-lg md:text-xl text-slate-400 font-light max-w-xl">
            {t('tagline')}
          </p>

          {/* Core Features bullets */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center">
                <MapPin className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="text-sm">
                <p className="font-semibold text-slate-200">GPS Nearby Matching</p>
                <p className="text-xs text-slate-500">Jobs within walking distance</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-primary-400" />
              </div>
              <div className="text-sm">
                <p className="font-semibold text-slate-200">Multi-Language Chat</p>
                <p className="text-xs text-slate-500">Auto translation for chats</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center">
                <Award className="w-5 h-5 text-amber-400" />
              </div>
              <div className="text-sm">
                <p className="font-semibold text-slate-200">Skill Courses</p>
                <p className="text-xs text-slate-500">Free certificates & tutorials</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center">
                <PlayCircle className="w-5 h-5 text-rose-400" />
              </div>
              <div className="text-sm">
                <p className="font-semibold text-slate-200">Audio Assistance</p>
                <p className="text-xs text-slate-500">Simple voice-based search</p>
              </div>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="pt-8 border-t border-slate-900 flex flex-wrap gap-8">
            <div>
              <p className="text-3xl font-extrabold text-white">45,000+</p>
              <p className="text-xs text-slate-500">Registered Workers</p>
            </div>
            <div>
              <p className="text-3xl font-extrabold text-white">12,500+</p>
              <p className="text-xs text-slate-500">Jobs Completed</p>
            </div>
            <div>
              <p className="text-3xl font-extrabold text-white">₹4.2 Cr</p>
              <p className="text-xs text-slate-500">Wages Released</p>
            </div>
            <div>
              <p className="text-3xl font-extrabold text-emerald-400">99.4%</p>
              <p className="text-xs text-slate-500">Payment Escrow Success</p>
            </div>
          </div>
        </div>

        {/* Right Side: Interactive Registration Card */}
        <div className="lg:col-span-5">
          <div className="glass-panel border border-slate-800 rounded-3xl p-8 relative shadow-2xl">
            {/* Visual element */}
            <div className="absolute top-0 right-0 w-24 h-24 bg-primary-500/10 rounded-full blur-xl pointer-events-none" />

            <h3 className="text-2xl font-bold text-slate-100 mb-6 flex items-center gap-2">
              <UserCheck className="w-6 h-6 text-primary-400" />
              Get Started Now
            </h3>

            {/* MOCK ALERT LOGS */}
            {message && (
              <div className="mb-6 p-4 rounded-xl bg-primary-950/60 border border-primary-900 text-xs text-primary-300 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-primary-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">System Alert</p>
                  <p>{message}</p>
                </div>
              </div>
            )}

            {/* STEP 1: Select User Role */}
            {step === 'role' && (
              <div className="space-y-6">
                <p className="text-sm text-slate-400">Please choose how you want to use the platform:</p>
                
                <div className="grid grid-cols-1 gap-4">
                  <button
                    onClick={() => {
                      setSelectedRole('worker');
                      setStep('phone');
                    }}
                    className="flex items-center gap-4 text-left p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-primary-500 hover:bg-slate-900/80 transition-all group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:bg-emerald-500/20">
                      <Briefcase className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-200">{t('role_worker')}</p>
                      <p className="text-xs text-slate-500">Carpenters, Painters, Electricians, Drivers, Welder, and Helpers</p>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      setSelectedRole('employer');
                      setStep('phone');
                    }}
                    className="flex items-center gap-4 text-left p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-primary-500 hover:bg-slate-900/80 transition-all group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-primary-500/10 text-primary-400 flex items-center justify-center group-hover:bg-primary-500/20">
                      <UserCheck className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-200">{t('role_employer')}</p>
                      <p className="text-xs text-slate-500">Contractors, Builders, Shopkeepers, and House owners hiring labour</p>
                    </div>
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: Phone Input */}
            {step === 'phone' && (
              <form onSubmit={handleSendOtp} className="space-y-5">
                <label className="block space-y-2">
                  <span className="text-sm font-semibold text-slate-300">Enter Phone Number</span>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-semibold">+91</span>
                    <input
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                      maxLength={10}
                      placeholder="98765 43210"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3.5 pl-14 pr-4 focus:ring-2 focus:ring-primary-500 focus:outline-none text-slate-100 font-semibold"
                    />
                  </div>
                </label>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setStep('role')}
                    className="w-1/3 py-3.5 bg-slate-900 border border-slate-800 text-slate-400 font-bold rounded-xl hover:bg-slate-850"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="w-2/3 py-3.5 bg-gradient-premium text-white font-bold rounded-xl shadow-lg shadow-primary-500/20 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  >
                    <Phone className="w-4 h-4" />
                    Send OTP Verification
                  </button>
                </div>
              </form>
            )}

            {/* STEP 3: OTP Input */}
            {step === 'otp' && (
              <form onSubmit={handleVerifyOtp} className="space-y-5">
                <label className="block space-y-2">
                  <span className="text-sm font-semibold text-slate-300">Enter 6-Digit OTP</span>
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                    maxLength={6}
                    placeholder="Enter Code"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3.5 text-center focus:ring-2 focus:ring-primary-500 focus:outline-none text-slate-100 tracking-[1em] font-extrabold text-xl"
                  />
                </label>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setStep('phone')}
                    className="w-1/3 py-3.5 bg-slate-900 border border-slate-800 text-slate-400 font-bold rounded-xl hover:bg-slate-850"
                  >
                    Resend
                  </button>
                  <button
                    type="submit"
                    className="w-2/3 py-3.5 bg-gradient-premium text-white font-bold rounded-xl shadow-lg shadow-primary-500/20 hover:brightness-110 active:scale-[0.98] transition-all"
                  >
                    Verify Code
                  </button>
                </div>
              </form>
            )}

            {/* STEP 4: Details Registration */}
            {step === 'details' && (
              <form onSubmit={handleCompleteRegister} className="space-y-5">
                <label className="block space-y-2">
                  <span className="text-sm font-semibold text-slate-300">Your Full Name</span>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="E.g., Ramesh Kumar"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3.5 px-4 focus:ring-2 focus:ring-primary-500 focus:outline-none text-slate-100"
                  />
                </label>

                {selectedRole === 'worker' && (
                  <>
                    <div className="space-y-2">
                      <span className="text-sm font-semibold text-slate-300">Select Your Skills</span>
                      <div className="flex flex-wrap gap-2">
                        {popularSkills.map((skill) => (
                          <button
                            key={skill}
                            type="button"
                            onClick={() => toggleSkill(skill)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                              skillsSelected.includes(skill)
                                ? 'bg-primary-600 border-primary-500 text-white'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            {skill}
                          </button>
                        ))}
                      </div>
                    </div>

                    <label className="block space-y-2">
                      <span className="text-sm font-semibold text-slate-300">Expected Daily Wage (INR)</span>
                      <div className="relative">
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-semibold">₹</span>
                        <input
                          type="number"
                          value={dailyWage}
                          onChange={(e) => setDailyWage(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3.5 pl-8 pr-4 focus:ring-2 focus:ring-primary-500 focus:outline-none text-slate-100 font-semibold"
                        />
                      </div>
                    </label>
                  </>
                )}

                {selectedRole === 'employer' && (
                  <label className="block space-y-2">
                    <span className="text-sm font-semibold text-slate-300">Company Name / Builder Details</span>
                    <input
                      type="text"
                      placeholder="E.g., Kamal Builders / Residential Owner"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3.5 px-4 focus:ring-2 focus:ring-primary-500 focus:outline-none text-slate-100"
                    />
                  </label>
                )}

                <button
                  type="submit"
                  className="w-full py-4 bg-emerald-600 text-white font-bold rounded-xl shadow-lg shadow-emerald-500/20 hover:bg-emerald-500 active:scale-[0.98] transition-all"
                >
                  Complete Account Creation
                </button>
              </form>
            )}

            {/* STEP 5: Success Navigation */}
            {step === 'success' && (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto animate-bounce">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <h4 className="text-xl font-bold text-white">Verification Complete!</h4>
                <p className="text-sm text-slate-400">Loading your personalized dashboard...</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
