import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import { connectMongoDB, connectRedis, pgPool } from './config/db';
import authRoutes from './routes/auth';
import jobRoutes from './routes/jobs';
import paymentRoutes from './routes/payments';
import chatRoutes from './routes/chats';
import { ChatModel, MessageModel } from '../../database/mongodb_schema';

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*', // In production, restrict this to specific clients
    methods: ['GET', 'POST']
  }
});

const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes Bindings
app.use('/api/auth', authRoutes);
app.use('/api/jobs', jobRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/chats', chatRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date() });
});

// Simple mock translation engine (simulating AI translation service for multi-language chat)
const translateMessage = (text: string) => {
  // Simple dictionary mapping for demo (in production, use Google Translate API or HuggingFace AI translation model)
  const dicts: Record<string, Record<string, string>> = {
    "hello": {
      hi: "नमस्ते (Namaste)",
      kn: "ಹಲೋ (Hello)",
      ta: "வணக்கம் (Vanakkam)",
      te: "హలో (Hello)",
      bn: "হ্যালো (Hello)",
      mr: "नमस्कार (Namaskar)",
      ur: "ہیلو (Hello)"
    },
    "i can start tomorrow": {
      hi: "मैं कल काम शुरू कर सकता हूँ।",
      kn: "ನಾನು ನಾಳೆ ಕೆಲಸ ಪ್ರಾರಂಭಿಸಬಹುದು.",
      ta: "நான் நாளை வேலை தொடங்கலாம்.",
      te: "నేను రేపు పని ప్రారంభించగలను.",
      bn: "আমি আগামীকাল কাজ শুরু করতে পারি।",
      mr: "मी उद्या काम सुरू करू शकतो.",
      ur: "میں کل کام شروع کر سکتا ہوں۔"
    }
  };

  const clean = text.toLowerCase().trim();
  const matched = dicts[clean];

  if (matched) {
    return { en: text, ...matched };
  }

  // Fallback translation mimic
  return {
    en: text,
    hi: `[अनुवादित] ${text}`,
    kn: `[ಅನುವಾದಿಸಲಾಗಿದೆ] ${text}`,
    ta: `[மொழிபெயர்க்கப்பட்டது] ${text}`,
    te: `[అనువదించబడింది] ${text}`,
    bn: `[অনূদিত] ${text}`,
    mr: `[भाषांतरित] ${text}`,
    ur: `[ترجمہ شدہ] ${text}`
  };
};

// WebSocket Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(`Socket client connected: ${socket.id}`);

  // User joins a private chat room
  socket.on('join_room', (roomId) => {
    socket.join(roomId);
    console.log(`Client ${socket.id} joined room: ${roomId}`);
  });

  // User sends message
  socket.on('send_msg', async (data) => {
    const { chatId, senderId, text, messageType = 'text', mediaUrl = '' } = data;

    try {
      // Mock translations cache
      const translations = messageType === 'text' ? translateMessage(text) : {};

      // 1. Save message to MongoDB
      const newMsg = await MessageModel.create({
        chatId,
        senderId,
        messageType,
        content: {
          text,
          mediaUrl
        },
        translations
      });

      // 2. Update last message in Chat Room
      await ChatModel.findByIdAndUpdate(chatId, {
        lastMessage: {
          text: messageType === 'text' ? text : `[Sent ${messageType}]`,
          senderId,
          timestamp: new Date()
        }
      });

      // 3. Emit message back to all clients in the room
      io.to(chatId).emit('receive_msg', newMsg);
      console.log(`Message in room ${chatId} broadcasted.`);
    } catch (err) {
      console.error('Error saving/transmitting message via WS:', err);
    }
  });

  socket.on('disconnect', () => {
    console.log(`Socket client disconnected: ${socket.id}`);
  });
});

// Server Initialization
const startServer = async () => {
  try {
    // Attempt connections (errors will log, but won't crash if services aren't running locally)
    await connectMongoDB().catch(err => console.warn('Could not connect to MongoDB. Running in PostgreSQL-only fallback mode.'));
    await connectRedis().catch(err => console.warn('Could not connect to Redis. Rate limiting running in fallback mode.'));

    server.listen(PORT, () => {
      console.log(`========================================`);
      console.log(`  Backend Gateway running on port ${PORT} `);
      console.log(`========================================`);
    });
  } catch (error) {
    console.error('Server startup failed:', error);
  }
};

startServer();
