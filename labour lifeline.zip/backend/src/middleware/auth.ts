import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { redisClient } from '../config/db';

const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_key_12345';

export interface AuthRequest extends Request {
  user?: {
    id: string;
    role: 'worker' | 'employer' | 'admin';
    fullName: string;
    phoneNumber: string;
  };
}

// 1. Authenticate Token Middleware
export const authenticateToken = (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required.' });
  }

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token.' });
    }
    req.user = decoded as AuthRequest['user'];
    next();
  });
};

// 2. Authorize Roles Middleware
export const requireRole = (roles: Array<'worker' | 'employer' | 'admin'>) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Access denied: Insufficient permissions.' });
    }
    next();
  };
};

// 3. Redis-based Rate Limiter (API protection)
export const apiRateLimiter = async (req: Request, res: Response, next: NextFunction) => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown-ip';
  const redisKey = `rate_limit:${ip}`;
  
  try {
    if (!redisClient.isOpen) {
      return next(); // If Redis is unavailable, bypass rate limiter in fallback mode
    }

    const requests = await redisClient.incr(redisKey);
    
    if (requests === 1) {
      await redisClient.expire(redisKey, 60); // Reset rate limit window every 60 seconds
    }

    const LIMIT = 60; // 60 requests per minute
    if (requests > LIMIT) {
      return res.status(429).json({
        error: 'Too many requests. Please slow down and try again later.',
        retryAfterSeconds: 60
      });
    }

    next();
  } catch (error) {
    console.error('Rate limiting error:', error);
    next(); // Safe fallback
  }
};
