import { Router, Response } from 'express';
import { pgPool } from '../config/db';
import { authenticateToken, requireRole, AuthRequest } from '../middleware/auth';
import http from 'http';

const router = Router();

// Helper function to call external AI engine microservice
const fetchAiRecommendations = (payload: any): Promise<any> => {
  return new Promise((resolve, reject) => {
    const aiServiceUrl = process.env.AI_ENGINE_URL || 'http://localhost:8000';
    const parsedUrl = new URL(aiServiceUrl);
    
    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || 80,
      path: '/match',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve({ error: 'Failed to parse AI response', matches: [] });
        }
      });
    });

    req.on('error', (err) => {
      console.error('Error connecting to AI service:', err.message);
      resolve({ error: 'AI service unreachable', matches: [] }); // Fallback graceful response
    });

    req.write(JSON.stringify(payload));
    req.end();
  });
};

// 1. Post a Job (Employer only)
router.post('/', authenticateToken, requireRole(['employer']), async (req: AuthRequest, res: Response) => {
  const user = req.user!;
  const {
    title, description, job_type, salary_wage, workers_needed,
    timing_schedule, duration, food_accommodation_provided,
    job_address, latitude, longitude, contact_phone, required_skills
  } = req.body;

  if (!title || !description || !job_type || !salary_wage || !job_address || !latitude || !longitude || !contact_phone) {
    return res.status(400).json({ error: 'Missing required job posting fields.' });
  }

  const client = await pgPool.connect();
  try {
    await client.query('BEGIN');

    // Retrieve Employer Profile ID
    const empRes = await client.query('SELECT id FROM employers WHERE user_id = $1', [user.id]);
    if (empRes.rows.length === 0) {
      return res.status(404).json({ error: 'Employer profile not found.' });
    }
    const employerId = empRes.rows[0].id;

    // Insert Job
    const jobRes = await client.query(
      `INSERT INTO jobs (employer_id, title, description, job_type, salary_wage, workers_needed, 
                         timing_schedule, duration, food_accommodation_provided, job_address, 
                         latitude, longitude, contact_phone) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING *`,
      [
        employerId, title, description, job_type, salary_wage, workers_needed || 1,
        timing_schedule || '', duration || '', food_accommodation_provided || false,
        job_address, latitude, longitude, contact_phone
      ]
    );
    const job = jobRes.rows[0];

    // Associate Required Skills
    if (required_skills && Array.isArray(required_skills)) {
      for (const skillName of required_skills) {
        // Find or create skill
        let skillRes = await client.query('SELECT id FROM skills WHERE name = $1', [skillName]);
        let skillId: number;
        if (skillRes.rows.length === 0) {
          const newSkill = await client.query('INSERT INTO skills (name) VALUES ($1) RETURNING id', [skillName]);
          skillId = newSkill.rows[0].id;
        } else {
          skillId = skillRes.rows[0].id;
        }

        await client.query(
          'INSERT INTO job_required_skills (job_id, skill_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [job.id, skillId]
        );
      }
    }

    await client.query('COMMIT');
    res.status(201).json({ message: 'Job posted successfully.', job });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Job posting error:', error);
    res.status(500).json({ error: 'Server error posting job.' });
  } finally {
    client.release();
  }
});

// 2. Fetch Jobs with filters and nearby location query
router.get('/', async (req, res) => {
  const { keyword, job_type, lat, lng, max_distance_km = 15 } = req.query;

  try {
    let query = `
      SELECT j.*, e.company_name, e.trust_score as employer_trust_score,
             ARRAY_AGG(s.name) FILTER (WHERE s.name IS NOT NULL) AS required_skills
      FROM jobs j
      LEFT JOIN employers e ON j.employer_id = e.id
      LEFT JOIN job_required_skills jrs ON j.id = jrs.job_id
      LEFT JOIN skills s ON jrs.skill_id = s.id
    `;

    const whereClauses: string[] = ["j.status = 'active'"];
    const params: any[] = [];

    if (keyword) {
      params.push(`%${keyword}%`);
      whereClauses.push(`(j.title ILIKE $${params.length} OR j.description ILIKE $${params.length})`);
    }

    if (job_type) {
      params.push(job_type);
      whereClauses.push(`j.job_type = $${params.length}`);
    }

    // Nearby distance calculations (Haversine formula in KM)
    // 6371 * acos(cos(radians(lat)) * cos(radians(j.latitude)) * cos(radians(j.longitude) - radians(lng)) + sin(radians(lat)) * sin(radians(j.latitude)))
    if (lat && lng) {
      const latitude = parseFloat(lat as string);
      const longitude = parseFloat(lng as string);
      const distLimit = parseFloat(max_distance_km as string);
      
      params.push(latitude, longitude, distLimit);
      const latIdx = params.length - 2;
      const lngIdx = params.length - 1;
      const limitIdx = params.length;

      whereClauses.push(
        `(6371 * acos(
          cos(radians($${latIdx})) * cos(radians(j.latitude)) * 
          cos(radians(j.longitude) - radians($${lngIdx})) + 
          sin(radians($${latIdx})) * sin(radians(j.latitude))
        )) <= $${limitIdx}`
      );
    }

    if (whereClauses.length > 0) {
      query += ' WHERE ' + whereClauses.join(' AND ');
    }

    query += ' GROUP BY j.id, e.company_name, e.trust_score';

    const jobsRes = await pgPool.query(query, params);
    res.json({ jobs: jobsRes.rows });
  } catch (error) {
    console.error('Fetch jobs error:', error);
    res.status(500).json({ error: 'Server error retrieving jobs.' });
  }
});

// 3. Get matching jobs via AI Engine
router.get('/recommendations', authenticateToken, requireRole(['worker']), async (req: AuthRequest, res: Response) => {
  const user = req.user!;

  try {
    // 1. Fetch Worker Profile & Skills
    const workerRes = await pgPool.query(
      `SELECT w.id, w.daily_wage_expectation, w.latitude, w.longitude, w.experience_years,
              ARRAY_AGG(s.name) FILTER (WHERE s.name IS NOT NULL) AS skills
       FROM workers w
       LEFT JOIN users u ON w.user_id = u.id
       LEFT JOIN worker_skills ws ON w.id = ws.worker_id
       LEFT JOIN skills s ON ws.skill_id = s.id
       WHERE u.id = $1
       GROUP BY w.id`,
      [user.id]
    );

    if (workerRes.rows.length === 0) {
      return res.status(404).json({ error: 'Worker profile not found.' });
    }

    const worker = workerRes.rows[0];

    // 2. Fetch all active jobs to match against
    const jobsRes = await pgPool.query(
      `SELECT j.id, j.title, j.description, j.salary_wage, j.latitude, j.longitude,
              ARRAY_AGG(s.name) FILTER (WHERE s.name IS NOT NULL) AS required_skills
       FROM jobs j
       LEFT JOIN job_required_skills jrs ON j.id = jrs.job_id
       LEFT JOIN skills s ON jrs.skill_id = s.id
       WHERE j.status = 'active'
       GROUP BY j.id`
    );

    // 3. Call AI microservice to calculate similarity ranking
    const aiPayload = {
      worker: {
        skills: worker.skills || [],
        wage: parseFloat(worker.daily_wage_expectation),
        experience: worker.experience_years,
        lat: worker.latitude,
        lng: worker.longitude
      },
      jobs: jobsRes.rows.map((j: any) => ({
        id: j.id,
        title: j.title,
        description: j.description,
        skills: j.required_skills || [],
        wage: parseFloat(j.salary_wage),
        lat: j.latitude,
        lng: j.longitude
      }))
    };

    const matchingResult = await fetchAiRecommendations(aiPayload);

    // 4. Join AI recommendation list with job details
    const recommendedJobIds = matchingResult.matches.map((m: any) => m.job_id);

    if (recommendedJobIds.length === 0) {
      return res.json({ recommendations: [] });
    }

    const recommendedJobs = await pgPool.query(
      `SELECT j.*, e.company_name, e.trust_score as employer_trust_score,
              ARRAY_AGG(s.name) FILTER (WHERE s.name IS NOT NULL) AS required_skills
       FROM jobs j
       LEFT JOIN employers e ON j.employer_id = e.id
       LEFT JOIN job_required_skills jrs ON j.id = jrs.job_id
       LEFT JOIN skills s ON jrs.skill_id = s.id
       WHERE j.id = ANY($1::uuid[])
       GROUP BY j.id, e.company_name, e.trust_score`,
      [recommendedJobIds]
    );

    // Sort by the AI score order
    const recommendations = recommendedJobs.rows.map(job => {
      const matchDetails = matchingResult.matches.find((m: any) => m.job_id === job.id);
      return {
        ...job,
        match_score: matchDetails ? matchDetails.score : 0
      };
    }).sort((a, b) => b.match_score - a.match_score);

    res.json({ recommendations });
  } catch (error) {
    console.error('Job recommendation error:', error);
    res.status(500).json({ error: 'Server error fetching recommendations.' });
  }
});

// 4. Apply for a Job (Worker only)
router.post('/:id/apply', authenticateToken, requireRole(['worker']), async (req: AuthRequest, res: Response) => {
  const jobId = req.params.id;
  const user = req.user!;

  try {
    const workerRes = await pgPool.query('SELECT id FROM workers WHERE user_id = $1', [user.id]);
    if (workerRes.rows.length === 0) {
      return res.status(404).json({ error: 'Worker profile not found.' });
    }
    const workerId = workerRes.rows[0].id;

    // Submit application
    await pgPool.query(
      'INSERT INTO applications (job_id, worker_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [jobId, workerId]
    );

    res.status(201).json({ message: 'Application submitted successfully.' });
  } catch (error) {
    console.error('Job application error:', error);
    res.status(500).json({ error: 'Server error applying to job.' });
  }
});

// 5. Fetch applicants (Employer only)
router.get('/:id/applicants', authenticateToken, requireRole(['employer']), async (req: AuthRequest, res: Response) => {
  const jobId = req.params.id;

  try {
    const applicantsRes = await pgPool.query(
      `SELECT a.id as application_id, a.status as application_status, a.applied_at,
              w.id as worker_profile_id, w.age, w.gender, w.experience_years, w.daily_wage_expectation, 
              w.trust_score as worker_trust_score, w.completed_jobs_count, w.profile_photo_url,
              u.full_name as worker_name, u.phone_number as worker_phone
       FROM applications a
       JOIN workers w ON a.worker_id = w.id
       JOIN users u ON w.user_id = u.id
       WHERE a.job_id = $1`,
      [jobId]
    );

    res.json({ applicants: applicantsRes.rows });
  } catch (error) {
    console.error('Fetch applicants error:', error);
    res.status(500).json({ error: 'Server error retrieving applicants.' });
  }
});

// 6. Manage Application status (Employer only)
router.put('/applications/:appId/status', authenticateToken, requireRole(['employer']), async (req: AuthRequest, res: Response) => {
  const { appId } = req.params;
  const { status } = req.body; // 'shortlisted', 'hired', 'rejected', 'completed'

  if (!status) return res.status(400).json({ error: 'Status field is required.' });

  const client = await pgPool.connect();
  try {
    await client.query('BEGIN');

    // Update Application Status
    const appRes = await client.query(
      'UPDATE applications SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING job_id, worker_id',
      [status, appId]
    );

    if (appRes.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Application not found.' });
    }

    const { job_id, worker_id } = appRes.rows[0];

    // If status updated to 'hired', increment workers hired count on job record
    if (status === 'hired') {
      await client.query(
        'UPDATE jobs SET workers_hired = workers_hired + 1 WHERE id = $1',
        [job_id]
      );
      
      // Send notification alert to the worker
      const workerUserRes = await client.query('SELECT user_id FROM workers WHERE id = $1', [worker_id]);
      if (workerUserRes.rows.length > 0) {
        await client.query(
          `INSERT INTO notifications (user_id, title, message, type) 
           VALUES ($1, 'Congratulations! You are Hired', 'You have been selected for the job. Please check your chats.', 'job_alert')`,
          [workerUserRes.rows[0].user_id]
        );
      }
    }

    await client.query('COMMIT');
    res.json({ message: `Application status updated to ${status}.` });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Update application status error:', error);
    res.status(500).json({ error: 'Server error updating application.' });
  } finally {
    client.release();
  }
});

export default router;
