import { Router, Response } from 'express';
import { pgPool } from '../config/db';
import { authenticateToken, requireRole, AuthRequest } from '../middleware/auth';

const router = Router();

// 1. Initialize Payment (Escrow Deposit)
router.post('/deposit-escrow', authenticateToken, requireRole(['employer']), async (req: AuthRequest, res: Response) => {
  const user = req.user!;
  const { job_id, worker_id, amount, gateway } = req.body;

  if (!job_id || !worker_id || !amount || !gateway) {
    return res.status(400).json({ error: 'Missing payment fields (job_id, worker_id, amount, gateway).' });
  }

  const client = await pgPool.connect();
  try {
    await client.query('BEGIN');

    // Retrieve Employer Profile ID
    const empRes = await client.query('SELECT id FROM employers WHERE user_id = $1', [user.id]);
    if (empRes.rows.length === 0) {
      return res.status(404).json({ error: 'Employer profile not found.' });
    }
    const employerId = empRes.rows[0].id;

    // Simulate Payment Gateway call (Razorpay/Stripe/UPI check)
    const transactionId = `txn_${gateway.toLowerCase()}_${Math.random().toString(36).substr(2, 9)}`;
    const invoiceNumber = `INV-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

    // Create payment in PostgreSQL with status 'escrowed'
    const payRes = await client.query(
      `INSERT INTO payments (job_id, employer_id, worker_id, amount, status, gateway, transaction_id, invoice_number) 
       VALUES ($1, $2, $3, $4, 'escrowed', $5, $6, $7) RETURNING *`,
      [job_id, employerId, worker_id, amount, gateway, transactionId, invoiceNumber]
    );

    // Send notifications to both worker and employer
    await client.query(
      `INSERT INTO notifications (user_id, title, message, type) 
       VALUES ($1, 'Payment Deposited in Escrow', 'INR ' || $2 || ' deposited securely in escrow for the project.', 'payment')`,
      [user.id, amount]
    );

    const workerUserRes = await client.query('SELECT user_id FROM workers WHERE id = $1', [worker_id]);
    if (workerUserRes.rows.length > 0) {
      await client.query(
        `INSERT INTO notifications (user_id, title, message, type) 
         VALUES ($1, 'Payment Deposited in Escrow', 'An employer has escrowed INR ' || $2 || ' for your upcoming work.', 'payment')`,
        [workerUserRes.rows[0].user_id, amount]
      );
    }

    await client.query('COMMIT');
    res.status(201).json({
      message: 'Escrow payment established successfully.',
      payment: payRes.rows[0]
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Escrow deposit error:', error);
    res.status(500).json({ error: 'Server error processing payment.' });
  } finally {
    client.release();
  }
});

// 2. Release Escrow Payment (Employer releases to worker)
router.post('/release-escrow', authenticateToken, requireRole(['employer']), async (req: AuthRequest, res: Response) => {
  const { payment_id } = req.body;
  if (!payment_id) return res.status(400).json({ error: 'Payment ID required.' });

  const client = await pgPool.connect();
  try {
    await client.query('BEGIN');

    // Update payment record to released
    const payRes = await client.query(
      `UPDATE payments SET status = 'released', released_at = NOW() 
       WHERE id = $1 AND status = 'escrowed' RETURNING *`,
      [payment_id]
    );

    if (payRes.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No active escrow found for the specified Payment ID.' });
    }

    const payment = payRes.rows[0];

    // Increment worker completed jobs count
    await client.query(
      'UPDATE workers SET completed_jobs_count = completed_jobs_count + 1 WHERE id = $1',
      [payment.worker_id]
    );

    // Send release notifications
    const workerUserRes = await client.query('SELECT user_id FROM workers WHERE id = $1', [payment.worker_id]);
    if (workerUserRes.rows.length > 0) {
      await client.query(
        `INSERT INTO notifications (user_id, title, message, type) 
         VALUES ($1, 'Escrow Released!', 'Your daily wage payment of INR ' || $2 || ' has been transferred to your account.', 'payment')`,
        [workerUserRes.rows[0].user_id, payment.amount]
      );
    }

    await client.query('COMMIT');
    res.json({ message: 'Escrow released and funds transferred to worker account.', payment });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Release escrow error:', error);
    res.status(500).json({ error: 'Server error releasing escrow.' });
  } finally {
    client.release();
  }
});

// 3. Retrieve payment history for current user
router.get('/history', authenticateToken, async (req: AuthRequest, res: Response) => {
  const user = req.user!;

  try {
    let query = '';
    const params = [user.id];

    if (user.role === 'worker') {
      query = `
        SELECT p.*, j.title as job_title, u.full_name as employer_name 
        FROM payments p
        JOIN jobs j ON p.job_id = j.id
        JOIN employers e ON p.employer_id = e.id
        JOIN users u ON e.user_id = u.id
        JOIN workers w ON p.worker_id = w.id
        WHERE w.user_id = $1
        ORDER BY p.created_at DESC
      `;
    } else {
      query = `
        SELECT p.*, j.title as job_title, u.full_name as worker_name 
        FROM payments p
        JOIN jobs j ON p.job_id = j.id
        JOIN workers w ON p.worker_id = w.id
        JOIN users u ON w.user_id = u.id
        JOIN employers e ON p.employer_id = e.id
        WHERE e.user_id = $1
        ORDER BY p.created_at DESC
      `;
    }

    const payHistory = await pgPool.query(query, params);
    res.json({ payments: payHistory.rows });
  } catch (error) {
    console.error('Payment history error:', error);
    res.status(500).json({ error: 'Server error retrieving payments.' });
  }
});

// 4. Generate Invoice (JSON summary for frontend pdf renderer)
router.get('/invoice/:id', authenticateToken, async (req: AuthRequest, res: Response) => {
  const paymentId = req.params.id;

  try {
    const invRes = await pgPool.query(
      `SELECT p.*, j.title as job_title, j.job_address,
              wu.full_name as worker_name, wu.phone_number as worker_phone,
              eu.full_name as employer_name, e.company_name, e.address as employer_address
       FROM payments p
       JOIN jobs j ON p.job_id = j.id
       JOIN workers w ON p.worker_id = w.id
       JOIN users wu ON w.user_id = wu.id
       JOIN employers e ON p.employer_id = e.id
       JOIN users eu ON e.user_id = eu.id
       WHERE p.id = $1`,
      [paymentId]
    );

    if (invRes.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice details not found.' });
    }

    res.json({ invoice: invRes.rows[0] });
  } catch (error) {
    console.error('Generate invoice error:', error);
    res.status(500).json({ error: 'Server error building invoice.' });
  }
});

export default router;
