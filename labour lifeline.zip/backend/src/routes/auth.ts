import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { pgPool, redisClient } from '../config/db';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_key_12345';

// Helper to generate JWT token
const generateToken = (user: { id: string; role: string; full_name: string; phone_number: string }) => {
  return jwt.sign(
    { id: user.id, role: user.role, fullName: user.full_name, phoneNumber: user.phone_number },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
};

// 1. User Registration
router.post('/register', async (req, res) => {
  const { phone_number, email, password, role, full_name, additionalInfo } = req.body;

  if (!phone_number || !role || !full_name) {
    return res.status(400).json({ error: 'Missing required registration fields.' });
  }

  const client = await pgPool.connect();
  try {
    await client.query('BEGIN');

    // Check if user already exists
    const userCheck = await client.query('SELECT id FROM users WHERE phone_number = $1', [phone_number]);
    if (userCheck.rows.length > 0) {
      return res.status(400).json({ error: 'User with this phone number already registered.' });
    }

    const passwordHash = password ? await bcrypt.hash(password, 10) : null;

    // Create User record
    const userRes = await client.query(
      `INSERT INTO users (phone_number, email, password_hash, role, full_name) 
       VALUES ($1, $2, $3, $4, $5) RETURNING id, role, full_name, phone_number`,
      [phone_number, email || null, passwordHash, role, full_name]
    );
    const userId = userRes.rows[0].id;

    // Create sub-profile based on role
    if (role === 'worker') {
      const { age, gender, address, latitude, longitude, daily_wage_expectation, languages_known, experience_years } = additionalInfo || {};
      await client.query(
        `INSERT INTO workers (user_id, age, gender, address, latitude, longitude, daily_wage_expectation, languages_known, experience_years) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
        [
          userId,
          age || null,
          gender || 'other',
          address || '',
          latitude || 0,
          longitude || 0,
          daily_wage_expectation || 500.00,
          languages_known || [],
          experience_years || 0
        ]
      );
    } else if (role === 'employer') {
      const { company_name, business_category, address, latitude, longitude } = additionalInfo || {};
      await client.query(
        `INSERT INTO employers (user_id, company_name, business_category, address, latitude, longitude) 
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [
          userId,
          company_name || null,
          business_category || null,
          address || '',
          latitude || 0,
          longitude || 0
        ]
      );
    }

    await client.query('COMMIT');

    const token = generateToken(userRes.rows[0]);
    res.status(201).json({
      message: 'Registration successful.',
      token,
      user: { id: userId, role, fullName: full_name, phoneNumber: phone_number }
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Server error during registration.' });
  } finally {
    client.release();
  }
});

// 2. Email/Password Login
router.post('/login', async (req, res) => {
  const { identifier, password } = req.body; // identifier can be phone_number or email

  if (!identifier || !password) {
    return res.status(400).json({ error: 'Missing credentials.' });
  }

  try {
    const userRes = await pgPool.query(
      'SELECT * FROM users WHERE phone_number = $1 OR email = $1',
      [identifier]
    );

    if (userRes.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials.' });
    }

    const user = userRes.rows[0];
    if (!user.password_hash) {
      return res.status(400).json({ error: 'Account created via OAuth/OTP. Please log in using that method.' });
    }

    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials.' });
    }

    const token = generateToken(user);
    res.json({
      message: 'Login successful.',
      token,
      user: { id: user.id, role: user.role, fullName: user.full_name, phoneNumber: user.phone_number }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error during login.' });
  }
});

// 3. Send OTP (Simulated SMS Gateway)
router.post('/send-otp', async (req, res) => {
  const { phone_number } = req.body;
  if (!phone_number) {
    return res.status(400).json({ error: 'Phone number is required.' });
  }

  const otp = Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
  console.log(`[SMS-MOCK] Sending OTP ${otp} to phone number ${phone_number}`);

  try {
    if (redisClient.isOpen) {
      // Store OTP in Redis with a 5-minute expiration
      await redisClient.set(`otp:${phone_number}`, otp, { EX: 300 });
    }
    
    res.json({ message: 'OTP sent successfully (Simulated).', tempOtp: otp }); // returning OTP in response for demo purposes
  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({ error: 'Failed to send OTP.' });
  }
});

// 4. Verify OTP & Issue Token
router.post('/verify-otp', async (req, res) => {
  const { phone_number, otp } = req.body;

  if (!phone_number || !otp) {
    return res.status(400).json({ error: 'Missing phone number or OTP.' });
  }

  try {
    let cachedOtp: string | null = null;
    if (redisClient.isOpen) {
      cachedOtp = await redisClient.get(`otp:${phone_number}`);
    } else {
      cachedOtp = otp; // Fallback if Redis is down for local test simulation
    }

    if (cachedOtp !== otp) {
      return res.status(400).json({ error: 'Invalid or expired OTP.' });
    }

    // OTP validated. Fetch or create User
    const userRes = await pgPool.query('SELECT * FROM users WHERE phone_number = $1', [phone_number]);
    
    if (userRes.rows.length === 0) {
      // Return flag to complete registration on frontend
      return res.status(202).json({
        message: 'OTP verified. Account details required to complete registration.',
        phone_number
      });
    }

    const user = userRes.rows[0];
    const token = generateToken(user);

    // Remove OTP from Redis
    if (redisClient.isOpen) {
      await redisClient.del(`otp:${phone_number}`);
    }

    res.json({
      message: 'OTP verified. Login successful.',
      token,
      user: { id: user.id, role: user.role, fullName: user.full_name, phoneNumber: user.phone_number }
    });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ error: 'Verification failed.' });
  }
});

// 5. Mock Google OAuth Authentication
router.post('/google-login', async (req, res) => {
  const { googleToken, role } = req.body;

  if (!googleToken) {
    return res.status(400).json({ error: 'Google OAuth token is required.' });
  }

  // Mimic decoding Google ID token payload
  const email = 'googleUser@example.com';
  const name = 'Google User';
  const dummyPhone = '+919999911111';

  try {
    let userRes = await pgPool.query('SELECT * FROM users WHERE email = $1', [email]);

    if (userRes.rows.length === 0) {
      // First time user, register as Google user
      if (!role) {
        return res.status(202).json({
          message: 'Google verified. Choose a user role to complete sign up.',
          email,
          name
        });
      }

      const client = await pgPool.connect();
      try {
        await client.query('BEGIN');
        const insertedUser = await client.query(
          `INSERT INTO users (phone_number, email, role, full_name) 
           VALUES ($1, $2, $3, $4) RETURNING *`,
          [dummyPhone, email, role, name]
        );
        
        if (role === 'worker') {
          await client.query('INSERT INTO workers (user_id, daily_wage_expectation) VALUES ($1, 500.00)', [insertedUser.rows[0].id]);
        } else {
          await client.query('INSERT INTO employers (user_id) VALUES ($1)', [insertedUser.rows[0].id]);
        }
        await client.query('COMMIT');
        userRes = insertedUser;
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }
    }

    const user = userRes.rows[0];
    const token = generateToken(user);
    res.json({
      message: 'Google login successful.',
      token,
      user: { id: user.id, role: user.role, fullName: user.full_name, phoneNumber: user.phone_number }
    });
  } catch (error) {
    console.error('Google login error:', error);
    res.status(500).json({ error: 'Google OAuth processing failed.' });
  }
});

// 6. Fetch User Profile
router.get('/profile', authenticateToken, async (req: AuthRequest, res: Response) => {
  const user = req.user;
  if (!user) return res.status(401).json({ error: 'Unauthorized.' });

  try {
    let profileQuery = '';
    if (user.role === 'worker') {
      profileQuery = `
        SELECT u.id, u.phone_number, u.email, u.role, u.full_name,
               w.id as worker_profile_id, w.age, w.gender, w.address, w.latitude, w.longitude, 
               w.daily_wage_expectation, w.languages_known, w.experience_years, 
               w.availability_status, w.verification_status, w.trust_score, w.completed_jobs_count, w.profile_photo_url
        FROM users u 
        LEFT JOIN workers w ON u.id = w.user_id 
        WHERE u.id = $1`;
    } else if (user.role === 'employer') {
      profileQuery = `
        SELECT u.id, u.phone_number, u.email, u.role, u.full_name,
               e.id as employer_profile_id, e.company_name, e.business_category, e.address, e.latitude, e.longitude, 
               e.verification_status, e.trust_score
        FROM users u 
        LEFT JOIN employers e ON u.id = e.user_id 
        WHERE u.id = $1`;
    } else {
      profileQuery = `SELECT id, phone_number, email, role, full_name FROM users WHERE id = $1`;
    }

    const profileRes = await pgPool.query(profileQuery, [user.id]);
    if (profileRes.rows.length === 0) {
      return res.status(404).json({ error: 'Profile not found.' });
    }

    res.json({ profile: profileRes.rows[0] });
  } catch (error) {
    console.error('Fetch profile error:', error);
    res.status(500).json({ error: 'Server error retrieving profile.' });
  }
});

// 7. Update User Profile
router.put('/profile/update', authenticateToken, async (req: AuthRequest, res: Response) => {
  const user = req.user;
  if (!user) return res.status(401).json({ error: 'Unauthorized.' });

  const { full_name, email, ...additionalInfo } = req.body;

  const client = await pgPool.connect();
  try {
    await client.query('BEGIN');

    // Update core User details
    await client.query(
      'UPDATE users SET full_name = COALESCE($1, full_name), email = COALESCE($2, email), updated_at = NOW() WHERE id = $3',
      [full_name, email, user.id]
    );

    // Update role-specific table details
    if (user.role === 'worker') {
      const { age, gender, address, latitude, longitude, daily_wage_expectation, availability_status, languages_known, experience_years, profile_photo_url } = additionalInfo;
      await client.query(
        `UPDATE workers SET 
          age = COALESCE($1, age),
          gender = COALESCE($2, gender),
          address = COALESCE($3, address),
          latitude = COALESCE($4, latitude),
          longitude = COALESCE($5, longitude),
          daily_wage_expectation = COALESCE($6, daily_wage_expectation),
          availability_status = COALESCE($7, availability_status),
          languages_known = COALESCE($8, languages_known),
          experience_years = COALESCE($9, experience_years),
          profile_photo_url = COALESCE($10, profile_photo_url)
         WHERE user_id = $11`,
        [
          age,
          gender,
          address,
          latitude,
          longitude,
          daily_wage_expectation,
          availability_status,
          languages_known,
          experience_years,
          profile_photo_url,
          user.id
        ]
      );
    } else if (user.role === 'employer') {
      const { company_name, business_category, address, latitude, longitude } = additionalInfo;
      await client.query(
        `UPDATE employers SET 
          company_name = COALESCE($1, company_name),
          business_category = COALESCE($2, business_category),
          address = COALESCE($3, address),
          latitude = COALESCE($4, latitude),
          longitude = COALESCE($5, longitude)
         WHERE user_id = $6`,
        [
          company_name,
          business_category,
          address,
          latitude,
          longitude,
          user.id
        ]
      );
    }

    await client.query('COMMIT');
    res.json({ message: 'Profile updated successfully.' });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Server error updating profile.' });
  } finally {
    client.release();
  }
});

export default router;
