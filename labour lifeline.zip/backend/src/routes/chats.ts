import { Router, Response } from 'express';
import { authenticateToken, AuthRequest } from '../middleware/auth';
import { ChatModel, MessageModel } from '../../../database/mongodb_schema';

const router = Router();

// 1. Fetch all chat rooms for the logged-in user
router.get('/rooms', authenticateToken, async (req: AuthRequest, res: Response) => {
  const user = req.user!;

  try {
    // Query depends on user role
    const filter = user.role === 'employer' 
      ? { employerId: user.id } 
      : { workerId: user.id };

    const rooms = await ChatModel.find(filter).sort({ updatedAt: -1 }).lean();
    res.json({ rooms });
  } catch (error) {
    console.error('Fetch chat rooms error:', error);
    res.status(500).json({ error: 'Server error retrieving chat rooms.' });
  }
});

// 2. Fetch message history for a specific room
router.get('/rooms/:roomId/messages', authenticateToken, async (req: AuthRequest, res: Response) => {
  const { roomId } = req.params;

  try {
    const messages = await MessageModel.find({ chatId: roomId })
      .sort({ createdAt: 1 })
      .lean();

    res.json({ messages });
  } catch (error) {
    console.error('Fetch chat messages error:', error);
    res.status(500).json({ error: 'Server error loading messages.' });
  }
});

// 3. Initiate or Find an active chat room
router.post('/rooms', authenticateToken, async (req: AuthRequest, res: Response) => {
  const user = req.user!;
  const { jobId, targetUserId } = req.body; // targetUserId is either worker user_id or employer user_id

  if (!jobId || !targetUserId) {
    return res.status(400).json({ error: 'Missing jobId or targetUserId.' });
  }

  try {
    const employerId = user.role === 'employer' ? user.id : targetUserId;
    const workerId = user.role === 'worker' ? user.id : targetUserId;

    // Check if room already exists
    let room = await ChatModel.findOne({ jobId, employerId, workerId });

    if (!room) {
      room = await ChatModel.create({
        jobId,
        employerId,
        workerId,
        lastMessage: {
          text: 'Chat room initialized.',
          senderId: user.id,
          timestamp: new Date()
        }
      });
    }

    res.status(200).json({ room });
  } catch (error) {
    console.error('Create/Find chat room error:', error);
    res.status(500).json({ error: 'Server error initializing chat.' });
  }
});

export default router;
