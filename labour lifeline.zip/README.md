# AI-Powered Skilled & Unskilled Labour Hiring Platform

A startup-level, production-grade workforce marketplace connecting skilled, semi-skilled, and unskilled workers (electricians, painters, plumbers, construction workers, drivers, farm workers) with employers, contractors, and local service providers.

---

## 🚀 Key Features

1. **Aadhaar Verified Worker & Employer Profiles**: Ensures security with trust scores, verified credentials, and completed job tickers.
2. **GPS Nearby Job Locators**: Haversine formula-backed spatial searches listing jobs within walking distance.
3. **AI-Based Smart Matchmaker**: Scikit-learn TF-IDF and Cosine Similarity models pairing workers' expectations (skills, daily wages, locations) with job requirements.
4. **Multilingual Real-Time Chat & Translation**: Socket.IO messaging with automatic background translation between English, Hindi, Kannada, Tamil, Telugu, Marathi, Bengali, and Urdu.
5. **Simulated AI Voice Assistant**: Accessible voice-triggered job searches allowing workers to look up positions hands-free (mimicking Whisper AI/NLP intent classification).
6. **NSDC Certification Module & Quizzes**: Gamified training modules that grant workers a verified credential badge upon scoring 100%.
7. **Protected Escrow Payment Gateway**: Simulated Stripe & Razorpay transactions securing daily wages in escrow, released automatically upon job confirmation.
8. **Recruitment Analytics Board**: SVG-rendered expense logs, active hires, and demand heatmap insights for employers.

---

## 📂 Project Directory Structure

```
labour-platform/
│
├── database/
│   ├── schema.sql           # PostgreSQL tables (users, workers, jobs, payments, courses, etc.)
│   ├── mongodb_schema.js     # MongoDB collections (chats, messages history, worker portfolios)
│   └── seed.js              # Database seed script for immediate testing
│
├── backend/
│   ├── tsconfig.json        # TypeScript configuration
│   ├── package.json         # Backend node dependencies
│   └── src/
│       ├── server.ts        # App Entry point, WebSockets server, auto-translations
│       ├── config/db.ts     # Connections configuration (PostgreSQL pool, Mongoose, Redis)
│       ├── middleware/auth.ts # JWT authentication, role guards, Redis rate limiting
│       └── routes/
│           ├── auth.ts      # Authentication API (email/pass, Google, simulated OTP)
│           ├── jobs.ts      # Job listings, application management, nearby calculations
│           ├── payments.ts  # Escrow deposits, wage releases, invoice builders
│           └── chats.ts     # MongoDB chat room listings and message histories
│
├── ai-engine/
│   ├── requirements.txt     # Python packages configuration
│   └── main.py              # FastAPI server (Cosine matching, Voice NLU, Fraud audits, Bio builder)
│
├── frontend/                # Next.js 14 App Router (Tailwind + TypeScript)
│   ├── package.json
│   ├── tailwind.config.js
│   └── src/
│       ├── context/
│           ├── AuthContext.tsx       # Auth session cache and stand-alone demo fallback
│           └── LanguageContext.tsx   # Multi-language translation dictionaries
│       └── app/
│           ├── globals.css           # Custom stylesheets, glassmorphic effects, animations
│           ├── layout.tsx            # Main layout wrapper
│           ├── page.tsx              # Premium landing page & registration wizard
│           ├── chat/page.tsx         # Real-time WebSocket translation chat interface
│           └── dashboard/
│               ├── worker/page.tsx   # Worker UI (Job locator feed, Voice Assistant, Quiz certification)
│               └── employer/page.tsx # Employer UI (Job publisher, applicant tracker, analytics)
│
├── mobile-app/              # React Native Mobile App (Expo)
│   ├── package.json
│   └── App.tsx              # Mobile Screens (Jobs feed, Chat rooms, Voice Assist, Profiles)
│
├── docker/
│   ├── Dockerfile.backend   # Multi-stage Express gateway image builder
│   ├── Dockerfile.frontend  # Multi-stage Next.js client image builder
│   └── Dockerfile.ai        # FastAPI python server image builder
│
├── docs/
│   ├── nginx.conf           # Reverse proxy configuration
│   └── DEPLOYMENT.md        # AWS, GCP, and Kubernetes cloud setup steps
│
└── docker-compose.yml       # Local orchestrator for multi-container services
```

---

## 🛠️ Environment Variables Setup

Create a `.env` file in the `backend/` and `ai-engine/` folders:

### Backend `.env`:
```env
PORT=5000
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/labour_db
MONGODB_URI=mongodb://localhost:27017/labour_db
REDIS_URL=redis://localhost:6379
AI_ENGINE_URL=http://localhost:8000
JWT_SECRET=super_secret_key_12345
```

### AI Engine `.env`:
```env
PORT=8000
```

---

## 🚀 Running the Platform

### Option A: Running Locally (Non-Dockerized)

Make sure you have Node.js (v18+) and Python (v3.9+) installed:

1. **Launch Databases**: Start local PostgreSQL, MongoDB, and Redis instances.
2. **Run Postgres Schema & Seed**:
   ```bash
   psql -U postgres -d labour_db -f database/schema.sql
   node database/seed.js
   ```
3. **Start Backend Gateway**:
   ```bash
   cd backend
   npm install
   npm run dev
   ```
4. **Start AI/ML Engine**:
   ```bash
   cd ai-engine
   pip install -r requirements.txt
   python main.py
   ```
5. **Start Frontend Web Portal**:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
6. **Start Mobile App**:
   ```bash
   cd mobile-app
   npm install
   npm run start
   ```

### Option B: Running with Docker Compose
Ensure you have Docker Desktop installed, then run:
```bash
docker-compose up --build
```
This builds and connects all databases, backend server, frontend app, and AI engine in a single command.
- Web Client: `http://localhost:3000`
- REST Gateway: `http://localhost:5000`
- AI Microservice: `http://localhost:8000`
