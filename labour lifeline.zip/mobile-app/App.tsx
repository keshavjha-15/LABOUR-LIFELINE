import React, { useState } from 'react';
import { 
  StyleSheet, Text, View, ScrollView, TouchableOpacity, 
  TextInput, SafeAreaView, StatusBar, Dimensions 
} from 'react-native';
import { 
  Briefcase, MessageSquare, Mic, User, 
  MapPin, ShieldCheck, PhoneCall, Volume2, Sparkles 
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

export default function App() {
  const [activeTab, setActiveTab] = useState<'jobs' | 'chat' | 'voice' | 'profile'>('jobs');
  const [voiceQuery, setVoiceQuery] = useState('');
  const [isListening, setIsListening] = useState(false);

  // Mock data
  const jobs = [
    { id: '1', title: 'Urgent Substation Electrician', employer: 'Kamal Builders Ltd', location: 'Whitefield', distance: '1.2 km', wage: '₹750/Day', match: '95%' },
    { id: '2', title: 'House Paint Project', employer: 'Rajesh Patel', location: 'Koramangala', distance: '3.8 km', wage: '₹550/Day', match: '82%' },
    { id: '3', title: 'Delivery Driver Needed', employer: 'Anand Logistics', location: 'Indiranagar', distance: '5.0 km', wage: '₹800/Day', match: '70%' }
  ];

  const handleVoicePress = () => {
    setIsListening(true);
    setVoiceQuery('Listening...');
    setTimeout(() => {
      setVoiceQuery('Find electrician jobs near me');
      setIsListening(false);
    }, 2000);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0b0f19" />
      
      {/* Dynamic Header */}
      <View style={styles.header}>
        <View style={styles.headerLogo}>
          <View style={styles.logoIcon}>
            <Sparkles size={16} color="#fff" />
          </View>
          <View>
            <Text style={styles.headerText}>ANTIGRAVITY LABOUR</Text>
            <Text style={styles.headerSubtext}>MOBILE APP PANEL</Text>
          </View>
        </View>
        
        <View style={styles.verifiedBadge}>
          <ShieldCheck size={14} color="#10b981" />
          <Text style={styles.verifiedText}>Aadhaar Verified</Text>
        </View>
      </View>

      {/* Screen Views based on Active Tab */}
      <View style={styles.mainContent}>
        
        {/* TAB 1: Jobs feed */}
        {activeTab === 'jobs' && (
          <ScrollView contentContainerStyle={styles.scrollContent}>
            <Text style={styles.sectionTitle}>Nearby Job Openings</Text>
            
            {jobs.map((job) => (
              <View key={job.id} style={styles.jobCard}>
                <View style={styles.jobHeader}>
                  <Text style={styles.jobTitle}>{job.title}</Text>
                  <View style={styles.matchBadge}>
                    <Text style={styles.matchText}>{job.match} Match</Text>
                  </View>
                </View>
                
                <Text style={styles.employerName}>{job.employer}</Text>
                
                <View style={styles.jobMetaRow}>
                  <View style={styles.metaItem}>
                    <MapPin size={12} color="#94a3b8" />
                    <Text style={styles.metaText}>{job.location} ({job.distance})</Text>
                  </View>
                  <Text style={styles.wageText}>{job.wage}</Text>
                </View>

                <View style={styles.buttonRow}>
                  <TouchableOpacity style={[styles.cardBtn, styles.secondaryBtn]}>
                    <Text style={styles.secondaryBtnText}>Message</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity style={[styles.cardBtn, styles.primaryBtn]}>
                    <Text style={styles.primaryBtnText}>Apply Now</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </ScrollView>
        )}

        {/* TAB 2: Chat screen */}
        {activeTab === 'chat' && (
          <ScrollView contentContainerStyle={styles.scrollContent}>
            <Text style={styles.sectionTitle}>Conversations</Text>
            
            <TouchableOpacity style={styles.chatRoomItem}>
              <View style={styles.avatar}>
                <User size={20} color="#94a3b8" />
              </View>
              <View style={styles.chatDetails}>
                <Text style={styles.chatName}>Kamal Builders Ltd</Text>
                <Text style={styles.chatSubtitle}>Substation Electrician Project</Text>
                <Text style={styles.chatLastMsg}>Ramesh: I can start tomorrow morning...</Text>
              </View>
            </TouchableOpacity>
          </ScrollView>
        )}

        {/* TAB 3: AI Voice Assistant */}
        {activeTab === 'voice' && (
          <View style={styles.voiceContainer}>
            <Text style={styles.voiceTitle}>AI Multilingual Assistant</Text>
            <Text style={styles.voiceDesc}>
              Tap the button and ask in English, Hindi, Kannada, or Tamil. E.g., "Find carpenter work near me"
            </Text>

            <TouchableOpacity 
              style={[styles.micButton, isListening && styles.micActive]} 
              onPress={handleVoicePress}
            >
              <Mic size={32} color="#fff" />
            </TouchableOpacity>

            <View style={styles.transcriptBox}>
              <Text style={styles.transcriptText}>
                {voiceQuery || "Tap mic to speak..."}
              </Text>
            </View>

            <TouchableOpacity style={styles.audioFeedbackBtn}>
              <Volume2 size={16} color="#4f73ff" />
              <Text style={styles.audioFeedbackText}>Play Instructions Audio</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* TAB 4: Profile */}
        {activeTab === 'profile' && (
          <ScrollView contentContainerStyle={styles.scrollContent}>
            <View style={styles.profileHeader}>
              <View style={styles.largeAvatar}>
                <User size={40} color="#64748b" />
              </View>
              <Text style={styles.profileName}>Ramesh Kumar</Text>
              <Text style={styles.profilePhone}>+91 98765 43210</Text>
            </View>

            <View style={styles.infoSection}>
              <Text style={styles.infoLabel}>Skills</Text>
              <Text style={styles.infoValue}>Electrician, Motor Mechanic</Text>
              
              <Text style={styles.infoLabel}>Daily Wage Requirement</Text>
              <Text style={styles.infoValue}>₹600 / Day</Text>

              <Text style={styles.infoLabel}>Trust Rating</Text>
              <Text style={styles.infoValue}>⭐ 4.8 / 5.0 (15 completed jobs)</Text>
            </View>
          </ScrollView>
        )}

      </View>

      {/* Navigation bottom bar with big targets */}
      <View style={styles.tabBar}>
        <TouchableOpacity 
          style={[styles.tabItem, activeTab === 'jobs' && styles.tabActive]} 
          onPress={() => setActiveTab('jobs')}
        >
          <Briefcase size={20} color={activeTab === 'jobs' ? '#4f73ff' : '#64748b'} />
          <Text style={[styles.tabLabel, activeTab === 'jobs' && styles.tabLabelActive]}>Jobs</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.tabItem, activeTab === 'chat' && styles.tabActive]} 
          onPress={() => setActiveTab('chat')}
        >
          <MessageSquare size={20} color={activeTab === 'chat' ? '#4f73ff' : '#64748b'} />
          <Text style={[styles.tabLabel, activeTab === 'chat' && styles.tabLabelActive]}>Chat</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.tabItem, activeTab === 'voice' && styles.tabActive]} 
          onPress={() => setActiveTab('voice')}
        >
          <Mic size={20} color={activeTab === 'voice' ? '#4f73ff' : '#64748b'} />
          <Text style={[styles.tabLabel, activeTab === 'voice' && styles.tabLabelActive]}>Voice</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.tabItem, activeTab === 'profile' && styles.tabActive]} 
          onPress={() => setActiveTab('profile')}
        >
          <User size={20} color={activeTab === 'profile' ? '#4f73ff' : '#64748b'} />
          <Text style={[styles.tabLabel, activeTab === 'profile' && styles.tabLabelActive]}>Profile</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0b0f19',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
    backgroundColor: '#0b0f19',
  },
  headerLogo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoIcon: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: '#4f73ff',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  headerText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
    letterSpacing: 0.5,
  },
  headerSubtext: {
    color: '#64748b',
    fontSize: 8,
    fontWeight: 'bold',
  },
  verifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#064e3b',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  verifiedText: {
    color: '#10b981',
    fontSize: 9,
    fontWeight: 'bold',
    marginLeft: 4,
  },
  mainContent: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  jobCard: {
    backgroundColor: '#0f172a',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#1e293b',
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  jobTitle: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
    flex: 1,
  },
  matchBadge: {
    backgroundColor: '#064e3b',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  matchText: {
    color: '#10b981',
    fontSize: 9,
    fontWeight: 'bold',
  },
  employerName: {
    color: '#64748b',
    fontSize: 11,
    marginTop: 4,
  },
  jobMetaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  metaText: {
    color: '#94a3b8',
    fontSize: 11,
    marginLeft: 4,
  },
  wageText: {
    color: '#38bdf8',
    fontSize: 12,
    fontWeight: 'bold',
  },
  buttonRow: {
    flexDirection: 'row',
    marginTop: 12,
    gap: 8,
  },
  cardBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primaryBtn: {
    backgroundColor: '#4f73ff',
  },
  primaryBtnText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: 'bold',
  },
  secondaryBtn: {
    backgroundColor: '#1e293b',
    borderWidth: 1,
    borderColor: '#334155',
  },
  secondaryBtnText: {
    color: '#d1d5db',
    fontSize: 11,
    fontWeight: 'bold',
  },
  chatRoomItem: {
    flexDirection: 'row',
    backgroundColor: '#0f172a',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#1e293b',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#1e293b',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  chatDetails: {
    flex: 1,
  },
  chatName: {
    color: '#fff',
    fontSize: 13,
    fontWeight: 'bold',
  },
  chatSubtitle: {
    color: '#4f73ff',
    fontSize: 10,
    fontWeight: 'bold',
    marginTop: 2,
  },
  chatLastMsg: {
    color: '#64748b',
    fontSize: 11,
    marginTop: 4,
  },
  voiceContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  voiceTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  voiceDesc: {
    color: '#64748b',
    fontSize: 12,
    textAlign: 'center',
    lineHeight: 18,
    marginBottom: 32,
  },
  micButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#1e293b',
    borderWidth: 1,
    borderColor: '#334155',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 32,
    shadowColor: '#4f73ff',
    shadowOpacity: 0.1,
    shadowRadius: 10,
  },
  micActive: {
    backgroundColor: '#ef4444',
    borderColor: '#f87171',
  },
  transcriptBox: {
    backgroundColor: '#0f172a',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#1e293b',
    width: '100%',
    alignItems: 'center',
    marginBottom: 24,
  },
  transcriptText: {
    color: '#d1d5db',
    fontSize: 12,
    fontWeight: 'bold',
  },
  audioFeedbackBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1e293b',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#334155',
  },
  audioFeedbackText: {
    color: '#4f73ff',
    fontSize: 11,
    fontWeight: 'bold',
    marginLeft: 6,
  },
  profileHeader: {
    alignItems: 'center',
    marginVertical: 16,
  },
  largeAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#1e293b',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  profileName: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  profilePhone: {
    color: '#64748b',
    fontSize: 12,
    marginTop: 4,
  },
  infoSection: {
    backgroundColor: '#0f172a',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#1e293b',
    marginTop: 16,
  },
  infoLabel: {
    color: '#64748b',
    fontSize: 10,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginTop: 12,
  },
  infoValue: {
    color: '#fff',
    fontSize: 13,
    marginTop: 4,
  },
  tabBar: {
    flexDirection: 'row',
    height: 64,
    borderTopWidth: 1,
    borderTopColor: '#1e293b',
    backgroundColor: '#0b0f19',
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
  },
  tabActive: {
    backgroundColor: '#0f172a',
  },
  tabLabel: {
    color: '#64748b',
    fontSize: 9,
    fontWeight: 'bold',
    marginTop: 4,
  },
  tabLabelActive: {
    color: '#4f73ff',
  },
});
